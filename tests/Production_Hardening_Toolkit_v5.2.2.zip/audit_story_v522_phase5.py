#!/usr/bin/env python3
"""Supplemental Phase 5 audits. Experimental evidence fixture format; NOT a canonical schema or full pipeline certification."""
import argparse, hashlib, json, math
from pathlib import Path
from audit_story_v522_phase4 import Phase4, readzip

HISTORY_COLLECTIONS = {
 'characters': 'character_id', 'canon_facts': 'fact_id',
 'episode_summaries': 'episode',
}
STATE_COLLECTIONS = {'milestones':'milestone_id','clues':'clue_id','consequences':'consequence_id',
                     'episode_designs':'episode','visual_locks':'character_id'}

def transition_issues(before, after, operation='CREATE_NEXT', authorized_retcons=None):
 """Checks structural immutability between successive snapshots (not semantic continuity)."""
 authorized_retcons=set(authorized_retcons or [])
 issues=[]
 def ck(ok, path, reason):
  if not ok:issues.append({'path':path,'message':reason})
 def indexed(items,k):return {x[k]:x for x in items}
 n=before.get('last_completed_episode');m=after.get('last_completed_episode')
 ck(type(n)==int and type(m)==int and m==n+1,'last_completed_episode','Expected exactly next episode')
 ck(before.get('series_title')==after.get('series_title'),'series_title','Series title changed')
 ck(before.get('schema_version')==after.get('schema_version'),'schema_version','Schema version changed')
 if operation not in ('CREATE_NEXT','START','CONTINUE','FINALIZE'):
  ck(False,'operation','Unsupported transition operation')
 for key,idfield in HISTORY_COLLECTIONS.items():
  old=indexed(before[key],idfield);new=indexed(after[key],idfield)
  for ident,item in old.items():
   ck(ident in new,f'{key}.{ident}','Previous item deleted')
   if ident in new and (key,ident) not in authorized_retcons:
    ck(new[ident]==item,f'{key}.{ident}','Historical item modified without explicit authorization')
  for ident,item in new.items():
   if ident not in old and key=='canon_facts':
    ck(item['established_episode']==m,f'{key}.{ident}','New fact not established in current episode')
   if ident not in old and key=='episode_summaries':
    ck(ident==m,f'{key}.{ident}','New summary belongs to wrong episode')
 old_char=indexed(before['characters'],'character_id');new_char=indexed(after['characters'],'character_id')
 for cid in set(old_char)&set(new_char):
  if ('characters',cid) not in authorized_retcons:
   ck(old_char[cid]['name']==new_char[cid]['name'],f'characters.{cid}.name','Character identity changed')
 # A thread may legitimately migrate OPEN -> RESOLVED, but not disappear or reopen.
 old_open=indexed(before['open_threads'],'thread_id');old_res=indexed(before['resolved_threads'],'thread_id')
 new_open=indexed(after['open_threads'],'thread_id');new_res=indexed(after['resolved_threads'],'thread_id')
 ck(not (set(new_open)&set(new_res)),'threads','Thread in both open and resolved')
 for ident,item in old_res.items():
  ck(ident in new_res,f'threads.{ident}','Resolved thread deleted or reopened')
  if ident in new_res and ('threads',ident) not in authorized_retcons:
   ck(new_res[ident]==item,f'threads.{ident}','Resolved history changed')
 for ident,item in old_open.items():
  ck(ident in new_open or ident in new_res,f'threads.{ident}','Open thread disappeared without resolution')
  if ident in new_open and ('threads',ident) not in authorized_retcons:
   ck(new_open[ident]['description']==item['description'],f'threads.{ident}','Thread identity changed')
  if ident in new_res and ('threads',ident) not in authorized_retcons:
   ck(new_res[ident]['description']==item['description'],f'threads.{ident}','Resolved thread changed identity')
 old_s=before['series_state'];new_s=after['series_state']
 if old_s['status']=='COMPLETED':ck(False,'series_state.status','Attempted to continue completed series')
 if operation=='FINALIZE':ck(new_s['status']=='COMPLETED','series_state.status','FINALIZE did not complete series')
 elif operation in ('START','CONTINUE','CREATE_NEXT'):ck(new_s['status']=='ACTIVE','series_state.status','Unexpected series completion')
 for key,idfield in STATE_COLLECTIONS.items():
  old=indexed(old_s[key],idfield);new=indexed(new_s[key],idfield)
  for ident,item in old.items():
   ck(ident in new,f'series_state.{key}.{ident}','Historical entity deleted')
   if ident not in new or (key,ident) in authorized_retcons:continue
   item2=new[ident]
   if key in ('episode_designs','visual_locks'):
    ck(item2==item,f'series_state.{key}.{ident}','Historical design/visual lock overwritten')
   elif key=='clues':
    for frozen in ('clue_id','thread_id','observation','introduced_episode','source_script_ids'):
     ck(item[frozen]==item2[frozen],f'series_state.clues.{ident}.{frozen}','Historical clue provenance modified')
    ck(not (item['status']!='UNRESOLVED' and item['status']!=item2['status']),f'series_state.clues.{ident}.status','Final clue status changed')
    ck(set(item['known_by']).issubset(item2['known_by']),f'series_state.clues.{ident}.known_by','Knowledge was erased')
   elif key=='milestones':
    for frozen in ('milestone_id','description','target_episode','required'):
     ck(item[frozen]==item2[frozen],f'series_state.milestones.{ident}.{frozen}','Milestone contract rewritten')
    ck(not (item['status'] in ('FULFILLED','CANCELLED') and item2['status']!=item['status']),f'series_state.milestones.{ident}.status','Settled milestone reopened')
   elif key=='consequences':
    for frozen in ('consequence_id','description','established_episode'):
     ck(item[frozen]==item2[frozen],f'series_state.consequences.{ident}.{frozen}','Consequence history changed')
    ck(not (item['status']=='RESOLVED' and item2['status']!='RESOLVED'),f'series_state.consequences.{ident}.status','Resolved consequence reopened')
 return issues

def measured_issues(story_bytes, video, evidence_bytes):
 """Verify explicit per-span evidence in PHASE-5 experimental JSON layout, not a prompt-defined schema."""
 errors=[]
 def ck(ok,path,msg):
  if not ok:errors.append({'path':path,'message':msg})
 try:
  evidence=json.loads(evidence_bytes)
  story=json.loads(story_bytes)
  cfg=video['timing_config']
  ck(video['timing_basis']=='MEASURED','video.timing_basis','Not measured')
  ck(cfg['method_id']=='ALIGNED_SPAN_TIMING_V1','video.timing_config.method_id','Wrong method')
  ck(isinstance(cfg['evidence_locator'],str) and bool(cfg['evidence_locator']),'video.timing_config.evidence_locator','Missing evidence locator')
  ck(evidence.get('evidence_version')=='phase5-test-1','evidence.evidence_version','Unknown experimental evidence format')
  ck(evidence.get('story_sha256')==hashlib.sha256(story_bytes).hexdigest(),'evidence.story_sha256','Evidence is for another story')
  items={s['id']:s['text'] for s in story['script']}
  clips={c['clip_id']:c for c in video['clips']}
  rows=evidence['aligned_spans'];groups={}
  for i,r in enumerate(rows):
   w=f'evidence.aligned_spans[{i}]';cid=r['clip_id'];groups.setdefault(cid,[]).append(r)
   ck(cid in clips,w+'.clip_id','Unknown clip');sid=r['script_id'];ck(sid in items,w+'.script_id','Unknown script item')
   if sid in items:
    ck(type(r['start_char'])==int and type(r['end_char'])==int and 0<=r['start_char']<r['end_char']<=len(items[sid]),w+'.offset','Invalid character offsets')
    if 0<=r['start_char']<r['end_char']<=len(items[sid]):ck(r['text_sha256']==hashlib.sha256(items[sid][r['start_char']:r['end_char']].encode('utf-8')).hexdigest(),w+'.text_sha256','Text hash mismatch')
   a,b=r['start_seconds'],r['end_seconds']
   ck(type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and 0<=a<b,w+'.time','Invalid time boundary')
  ck(set(groups)==set(clips),'evidence.aligned_spans','Missing/extraneous clips')
  all_ranges=[]
  for cid,clip in clips.items():
   rr=groups.get(cid,[]);expected=clip['source_spans']
   ck(len(rr)==len(expected),f'evidence.{cid}','Span count does not match clip')
   for i,(a,b) in enumerate(zip(rr,expected)):
    ck(all(a[k]==b[k] for k in ('script_id','start_char','end_char')),f'evidence.{cid}[{i}]','Source span linkage mismatch')
   for i in range(1,len(rr)):
    ck(rr[i]['start_seconds']>=rr[i-1]['end_seconds'],f'evidence.{cid}[{i}]','Span timing overlaps previous')
   if rr:
    total=sum(x['end_seconds']-x['start_seconds'] for x in rr)
    ck(abs(total-clip['estimated_seconds'])<=0.02,f'video.clips.{cid}.estimated_seconds','Measured duration mismatch')
    all_ranges.extend((x['start_seconds'],x['end_seconds']) for x in rr)
  all_ranges.sort()
  for i in range(1,len(all_ranges)):
   ck(all_ranges[i][0]>=all_ranges[i-1][1],f'evidence.timeline[{i}]','Global aligned spans overlap')
 except (KeyError,TypeError,ValueError,IndexError,OverflowError) as e:
  errors.append({'path':'measured.execution','message':repr(e)})
 return errors

def tokenizer_capability():
 """No guessing about model identity from installed Python package."""
 try:
  import sentencepiece
  library=sentencepiece.__version__
 except ImportError:library=None
 return {'sentencepiece_library_version':library,'pipeline_native_tokenizer_verified':False,
 'gate':'NOT_CHECKED','reason':'No validated Chroma1-HD pipeline tokenizer/config/normalizer/special-token policy supplied to this run'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--before');p.add_argument('--after');p.add_argument('--archive');args=p.parse_args()
 out={'tokenizer':tokenizer_capability()}
 if args.before and args.after:
  out['transition_issues']=transition_issues(json.loads(Path(args.before).read_text()),json.loads(Path(args.after).read_text()))
 if args.archive:out['package_issues']=Phase4().evaluate(readzip(args.archive))
 print(json.dumps(out,indent=2,ensure_ascii=False))
