#!/usr/bin/env python3
"""Reproducible phase4 mutation tests: tests PASS when malformed fixtures are rejected."""
import copy,json,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from audit_story_v522_phase4 import Phase4,readzip
from audit_story_v522_phase3 import strict_load
ROOT=Path(__file__).parent
RAW=readzip(ROOT/'story_v522_synthetic_schema_PARTIAL.zip')
ANCHORS=[json.loads((ROOT/'story_v522_serial_synthetic_fixtures'/f'anchor_after_episode_{n}.json').read_text()) for n in range(4)]
def checkraw(mutation):
 raw=RAW.copy();records={k:strict_load(raw[k]) for k in ['story.json','image_prompts.json','video_prompts.json','visual_plan.json','validation_report.json','manifest.json']};mutation(records)
 # direct test phase4 semantics, avoiding deliberately obsolete digest invalidation
 v=Phase4();story=records['story.json'];v.bindings(story,records['visual_plan.json'],records['image_prompts.json']);v.timing(story,records['video_prompts.json']);v.report(records['validation_report.json'],3)
 return v.issues
class TestPhase4(unittest.TestCase):
 def assertReject(self,fun,term):
  issues=fun();self.assertTrue(any(term in x['path'] or term in x['issue'] for x in issues),issues)
 def test_01_partial_fixture_accepted_by_implemented_checks(self):self.assertEqual(Phase4().evaluate(RAW),[])
 def test_02_anchor_0(self):self.assertEqual(self.anchor(ANCHORS[0]),[])
 def test_03_anchor_1(self):self.assertEqual(self.anchor(ANCHORS[1]),[])
 def test_04_anchor_2(self):self.assertEqual(self.anchor(ANCHORS[2]),[])
 def test_05_anchor_3(self):self.assertEqual(self.anchor(ANCHORS[3]),[])
 def anchor(self,a):
  v=Phase4();v.anchor(a);return v.issues
 def changeanchor(self,edit):
  a=copy.deepcopy(ANCHORS[3]);edit(a);return self.anchor(a)
 def test_06_legacy_anchor_root_rejected(self):self.assertReject(lambda:self.changeanchor(lambda a:a.pop('series_state')),'series_state')
 def test_07_duplicate_thread(self):self.assertReject(lambda:self.changeanchor(lambda a:a['open_threads'].append(copy.deepcopy(a['resolved_threads'][0]))),'threads_union')
 def test_08_future_fact(self):self.assertReject(lambda:self.changeanchor(lambda a:a['canon_facts'][0].update(established_episode=4)),'canon_facts')
 def test_09_missing_summary(self):self.assertReject(lambda:self.changeanchor(lambda a:a['episode_summaries'].pop()),'episode_summaries')
 def test_10_completed_with_next_contract(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state'].update(next_episode_contract={'episode':4,'premise':'abc','required_thread_ids':[],'forbidden_resolutions':[]})),'next_episode_contract')
 def test_11_planned_required_on_completed(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['milestones'][0].update(status='PLANNED',resolution=None)),'milestones')
 def test_12_unresolved_with_reveal(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['clues'][0].update(status='UNRESOLVED')),'revealed_episode')
 def test_13_unknown_clue_knower(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['clues'][0].update(known_by=['c999'])),'known_by')
 def test_14_unknown_thread_on_clue(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['clues'][0].update(thread_id='t_missing')),'thread_id')
 def test_15_duplicate_clue_id(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['clues'][1].update(clue_id='q001')),'clues')
 def test_16_visual_lock_unknown_char(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['visual_locks'][0].update(character_id='c999')),'visual_locks')
 def test_17_bad_design_case(self):self.assertReject(lambda:self.changeanchor(lambda a:a['series_state']['episode_designs'][0].update(case_type='NOT_A_CASE')),'case_type')
 def test_18_visual_wrong_zone_id(self):self.assertReject(lambda:checkraw(lambda d:d['visual_plan.json']['assets'][2].update(source_script_ids=['s0001'])),'source_script_ids')
 def test_19_visual_wrong_role(self):self.assertReject(lambda:checkraw(lambda d:d['visual_plan.json']['assets'][2].update(role='FAREWELL')),'role')
 def test_20_visual_duplicate_id(self):self.assertReject(lambda:checkraw(lambda d:d['visual_plan.json']['assets'][2].update(source_script_ids=['s0002','s0002'])),'source_script_ids')
 def test_21_cross_plan_character_ids(self):self.assertReject(lambda:checkraw(lambda d:d['visual_plan.json']['assets'][2].update(character_ids=['c001'])),'character_ids')
 def test_22_wrong_unavailable_timing_config(self):self.assertReject(lambda:checkraw(lambda d:d['video_prompts.json']['timing_config'].update(method_id='WRONG')),'timing_config')
 def test_23_unavailable_with_duration(self):self.assertReject(lambda:checkraw(lambda d:d['video_prompts.json']['clips'][0].update(estimated_seconds=4)),'estimated_seconds')
 def test_24_complete_with_empty_checks(self):self.assertReject(lambda:checkraw(lambda d:d['validation_report.json'].update(status='COMPLETE')),'checks')
 def test_25_duplicate_check_ids(self):
  def mutate(d):d['validation_report.json']['checks']=[{'id':'A','status':'PASS','method':'CODE','required':True,'target':'x','details':'ok'}]*2
  self.assertReject(lambda:checkraw(mutate),'checks.id')
 def test_26_required_gate_not_checked(self):
  def mutate(d):d['validation_report.json'].update(status='COMPLETE',checks=[{'id':'STORY_NOVELTY','status':'NOT_CHECKED','method':'MODEL_REVIEW','required':True,'target':'story','details':'Not available'}])
  self.assertReject(lambda:checkraw(mutate),'Required check incomplete')
 def test_27_estimated_duration(self):
  def mutate(d):
   v=d['video_prompts.json'];v['timing_basis']='ESTIMATED';v['timing_config']={'method_id':'WHITESPACE_RATE_V1','rate_per_minute':120,'evidence_locator':None}
   for c in v['clips']:
    span=c['source_spans'][0];s=next(s for s in d['story.json']['script'] if s['id']==span['script_id']);c['estimated_seconds']=round(len(s['text'].split())*.5/s['speed']+s['pause_ms']/1000,2)
  self.assertEqual(checkraw(mutate),[])
 def test_28_estimated_tampered_seconds(self):
  def mutate(d):
   v=d['video_prompts.json'];v['timing_basis']='ESTIMATED';v['timing_config']={'method_id':'WHITESPACE_RATE_V1','rate_per_minute':120,'evidence_locator':None}
   for c in v['clips']:
    span=c['source_spans'][0];s=next(s for s in d['story.json']['script'] if s['id']==span['script_id']);c['estimated_seconds']=round(len(s['text'].split())*.5/s['speed']+s['pause_ms']/1000,2)
   v['clips'][0]['estimated_seconds']+=1.0
  self.assertReject(lambda:checkraw(mutate),'estimated_seconds')
 def test_29_measured_without_evidence(self):
  def mutate(d):
   v=d['video_prompts.json'];v['timing_basis']='MEASURED';v['timing_config']={'method_id':'ALIGNED_SPAN_TIMING_V1','rate_per_minute':None,'evidence_locator':None}
   for c in v['clips']:c['estimated_seconds']=2.0
  self.assertReject(lambda:checkraw(mutate),'timing_config')
 def test_30_unrecognized_required_status(self):
  def mutate(d):d['validation_report.json']['checks']=[{'id':'X','status':'SKIPPED','method':'CODE','required':True,'target':'x','details':'x'}]
  self.assertReject(lambda:checkraw(mutate),'status')
if __name__=='__main__':unittest.main(verbosity=2)
