#!/usr/bin/env python3
"""Independent PARTIAL mechanical/conformance tests for story prompt v5.2.2.
Synthetic fixtures, NOT a full story schema validator, image quality test or E2E pipeline.
"""
import hashlib, io, json, os, re, tempfile, unicodedata, unittest, zipfile
from pathlib import Path
from PIL import Image

ROOT=Path('/mnt/data'); PROMPT=ROOT/'ChatGPT_prompt_v5.2.2.txt'; QUICK=ROOT/'ChatGPT_prompt_v5.2.2_Quickstart.txt'
ZONES=['GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL']
SCHEMA={'story':'4.1.3','package':'5.0.0','image':'1.1','cip':'1.0','catalog':'1.0'}
def h(b): return hashlib.sha256(b).hexdigest()
def strict_json(b):
 def pairs(x):
  d={}; names=set()
  for k,v in x:
   kn=unicodedata.normalize('NFC',k)
   if kn in names: raise ValueError('duplicate key NFC')
   names.add(kn);d[k]=v
  return d
 def no_const(x): raise ValueError('non-finite '+x)
 return json.loads(b.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=no_const)
def safe_path(name):
 if not isinstance(name,str) or not name or name.startswith('/') or '\\' in name or '\x00' in name or re.match(r'^[A-Za-z]:',name): return False
 return all(x not in ('','.','..') for x in name.split('/'))
def verify_archive(raw, expected=None):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  names=z.namelist(); norm=[unicodedata.normalize('NFC',x).casefold() for x in names]
  assert len(set(norm))==len(norm),'duplicate member/collision'
  assert all(safe_path(x) for x in names),'unsafe path'
  assert all(not ((i.external_attr>>16)&0o170000)==0o120000 for i in z.infolist()),'symlink'
  assert z.testzip() is None,'CRC error'
  if expected is not None: assert set(names)==set(expected),'file set mismatch'
  return {x:z.read(x) for x in names}
def make_zip(files):
 out=io.BytesIO()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for name,data in files.items(): z.writestr(name,data)
 return out.getvalue()
def make_png():
 b=io.BytesIO();Image.new('RGB',(32,20),(40,80,120)).save(b,format='PNG');return b.getvalue()
def valid_story():
 return {'schema_version':'4.1.3','meta':{'title':'Truyện thử nghiệm','series':None,'episode':1,'author':'Test','channel':'Demo','profile':'ADULT_STANDARD','age_band':'18+','language':'vi','genre':'Tâm lý','tone':'Dịu nhẹ','target_minutes':2.5,'estimated_minutes':0.18,'timing_method':'WHITESPACE_RATE_V1','tags':['demo']},'characters':[{'character_id':'c001','name':'An','age':28,'role':'Chính','appearance':'Tóc đen','personality':'Bình tĩnh','voice_note':'Trầm'}],'outline':[{'scene_id':f'sc{i:03d}','summary':z,'change':'Chuyển biến','setup_or_payoff':None} for i,z in enumerate(ZONES,1)],'script':[{'id':f's{i:04d}','zone':z,'scene_id':f'sc{i:03d}','speaker':'narrator','text':f'{z} Một câu chuyện bắt đầu.','emotion':'neutral','speed':1.0,'pause_ms':100,'ambience':None} for i,z in enumerate(ZONES,1)]}
def story_minimal_invariants(d):
 assert d['schema_version']=='4.1.3'
 assert isinstance(d['meta']['episode'],int) and not isinstance(d['meta']['episode'],bool)
 assert set(x['character_id'] for x in d['characters'])=={'c001'}
 scenes=[x['scene_id'] for x in d['outline']]
 assert [x['scene_id'] for x in d['script']]==scenes
 assert [x['zone'] for x in d['script']]==ZONES
 assert [x['id'] for x in d['script']]==[f's{i:04d}' for i in range(1,len(d['script'])+1)]
 assert all(x['speaker']=='narrator' or x['speaker'] in {c['character_id'] for c in d['characters']} for x in d['script'])
def fixture_package(extra=None, status='PARTIAL'):
 story=json.dumps(valid_story(),ensure_ascii=False,separators=(',',':')).encode()
 image={'image_prompt_version':'1.1','source_story':{'sha256':h(story)},'character_locks':[],'assets':[]}
 video={'schema_version':'4.1.3','source_story':{'sha256':h(story)},'clips':[]}
 report={'schema_version':'5.0.0','prompt_version':'5.2.2','stage':1,'status':status,'input_sources':['Synthetic test fixture — not production content'],'checks':[],'limitations':['Fixture uses no real tokenizer or images'],'remaining_work':['T5-512 verification','image/video payload'],'archive_validation':{'status':'NOT_CHECKED','details':'Postzip check outside archive'}}
 files={'story.json':story,'image_prompts.json':json.dumps(image).encode(),'video_prompts.json':json.dumps(video).encode(),'validation_report.json':json.dumps(report).encode()}
 if extra:files.update(extra)
 manifest={'schema_version':'5.0.0','prompt_version':'5.2.2','stage':1,'status':status,'parent_package_sha256':None,'files':[{'path':p,'size_bytes':len(b),'sha256':h(b),'origin_stage':1} for p,b in sorted(files.items())]}
 files['manifest.json']=json.dumps(manifest,ensure_ascii=False).encode()
 return files

def manifest_match(files):
 m=strict_json(files['manifest.json'])
 assert set(files)-{'manifest.json'}=={e['path'] for e in m['files']}
 for e in m['files']:
  b=files[e['path']];assert len(b)==e['size_bytes'] and h(b)==e['sha256']
 return True

def reference_decision(image_ready, approved, promised=False):
 if image_ready:return 'IMAGE_REFERENCE', 'PASS'
 if approved:return 'DESCRIPTION_ONLY_APPROVED','NOT_APPLICABLE'
 return 'REFERENCE_PENDING','NOT_CHECKED'
def stage1_decision(reference_gate, token_gate, novelty_gate, all_other=True):
 return 'COMPLETE' if reference_gate in ('PASS','NOT_APPLICABLE') and token_gate=='PASS' and novelty_gate=='PASS' and all_other else 'PARTIAL'
def catalog_gate(kind, serial_previous=0):
 if kind=='CATALOG_VERIFIED':return 'PASS'
 if kind=='FIRST_STORY_BASELINE' and serial_previous==0:return 'PASS'
 return 'NOT_CHECKED'
def route_anchor(n):
 if not isinstance(n,int) or isinstance(n,bool) or n<0: return 'BLOCKED'
 return 'START' if n==0 else f'CREATE_NEXT:{n+1}'

def spans_valid(text, spans):
 cursor=0; chunks=[]
 for start,end in spans:
  if not(isinstance(start,int) and isinstance(end,int) and 0<=start<end<=len(text) and start==cursor):return False
  chunks.append(text[start:end]);cursor=end
 return cursor==len(text) and ''.join(chunks)==text

def resume_good_files(known, expected):
 good=[]; missing=[]
 for p,v in expected.items():
  if p in known and h(known[p])==h(v):good.append(p)
  else:missing.append(p)
 return good,missing

class Conformance(unittest.TestCase):
 def test_01_prompt_quickstart_versions(self):
  a=PROMPT.read_text();b=QUICK.read_text();self.assertIn('5.2.2',a);self.assertIn('5.2.2',b);self.assertNotIn('v5.2.1',a+b)
 def test_02_schema_contract_and_gate_text(self):
  a=PROMPT.read_text()
  for s in ('4.1.3','5.0.0','image_prompt_version','FIRST_STORY_BASELINE','DESCRIPTION_ONLY_APPROVED','IMAGE_PROMPT_T5_TOKENS','28.7.'):self.assertIn(s,a)
 def test_03_strict_json_accept(self):self.assertEqual(strict_json(b'{"ok":1}'),{'ok':1})
 def test_04_strict_json_duplicate_reject(self):
  with self.assertRaises(ValueError):strict_json(b'{"a":1,"a":2}')
 def test_05_strict_json_nfc_duplicate_reject(self):
  with self.assertRaises(ValueError):strict_json('{"é":1,"e\u0301":2}'.encode())
 def test_06_strict_json_nonfinite_reject(self):
  with self.assertRaises(ValueError):strict_json(b'{"x":NaN}')
 def test_07_story_fixture_8_zones(self):story_minimal_invariants(valid_story())
 def test_08_story_fixture_invalid_speaker(self):
  d=valid_story();d['script'][0]['speaker']='c777'
  with self.assertRaises(AssertionError):story_minimal_invariants(d)
 def test_09_story_fixture_bool_episode(self):
  d=valid_story();d['meta']['episode']=True
  with self.assertRaises(AssertionError):story_minimal_invariants(d)
 def test_10_manifest_and_zip_positive(self):
  fs=fixture_package();self.assertTrue(manifest_match(fs));self.assertEqual(verify_archive(make_zip(fs),fs),fs)
 def test_11_manifest_corrupted_file_reject(self):
  fs=fixture_package();fs['story.json']+=b' '; 
  with self.assertRaises(AssertionError):manifest_match(fs)
 def test_12_manifest_extra_member_reject(self):
  fs=fixture_package();fs['unexpected.tmp']=b'x'
  with self.assertRaises(AssertionError):manifest_match(fs)
 def test_13_zip_traversal_reject(self):
  with self.assertRaises(AssertionError):verify_archive(make_zip({'../evil':b'x'}))
 def test_14_zip_case_collision_reject(self):
  with self.assertRaises(AssertionError):verify_archive(make_zip({'A.png':b'x','a.png':b'x'}))
 def test_15_zip_symlink_reject(self):
  bio=io.BytesIO()
  with zipfile.ZipFile(bio,'w') as z:
   i=zipfile.ZipInfo('link');i.create_system=3;i.external_attr=(0o120777<<16);z.writestr(i,'target')
  with self.assertRaises(AssertionError):verify_archive(bio.getvalue())
 def test_16_real_png_decode(self):
  b=make_png(); im=Image.open(io.BytesIO(b));im.load();self.assertEqual(im.size,(32,20))
 def test_17_fake_png_reject(self):
  with self.assertRaises(Exception):Image.open(io.BytesIO(b'not a PNG')).load()
 def test_18_reference_no_consent(self):self.assertEqual(reference_decision(False,False),('REFERENCE_PENDING','NOT_CHECKED'))
 def test_19_reference_approved(self):self.assertEqual(reference_decision(False,True),('DESCRIPTION_ONLY_APPROVED','NOT_APPLICABLE'))
 def test_20_stage1_missing_tokenizer_partial(self):self.assertEqual(stage1_decision('NOT_APPLICABLE','NOT_CHECKED','PASS'),'PARTIAL')
 def test_21_stage1_verified_branch(self):self.assertEqual(stage1_decision('NOT_APPLICABLE','PASS','PASS'),'COMPLETE')
 def test_22_first_story_baseline(self):self.assertEqual(catalog_gate('FIRST_STORY_BASELINE',0),'PASS')
 def test_23_serial_no_baseline(self):self.assertEqual(catalog_gate('FIRST_STORY_BASELINE',3),'NOT_CHECKED')
 def test_24_anchor_routes(self):self.assertEqual(route_anchor(0),'START');self.assertEqual(route_anchor(3),'CREATE_NEXT:4');self.assertEqual(route_anchor(-1),'BLOCKED')
 def test_25_unicode_codepoint_spans(self):
  t='A🙂 có dấu';self.assertTrue(spans_valid(t,[(0,2),(2,len(t))]));self.assertFalse(spans_valid(t,[(0,2),(3,len(t))]))
 def test_26_resume_only_missing_corrupt(self):
  exp={'landscape/a.png':b'goodA','landscape/b.png':b'goodB','landscape/c.png':b'goodC'}
  good,missing=resume_good_files({'landscape/a.png':b'goodA','landscape/b.png':b'corrupt'},exp)
  self.assertEqual(good,['landscape/a.png']);self.assertEqual(missing,['landscape/b.png','landscape/c.png'])
 def test_27_cip_front_bytes_preserved(self):
  front=make_png();cip={'characters/c001/front.png':front,'characters/c001/side.png':b'x'}
  s=fixture_package({'characters/c001.png':cip['characters/c001/front.png']})
  self.assertEqual(h(s['characters/c001.png']),h(front));self.assertNotIn('characters/c001/side.png',s)
 def test_28_stage1_nofile_count(self):self.assertEqual(len(fixture_package()),5)
 def test_29_stage2_parity_count(self):
  fs=fixture_package();fs['visual_plan.json']=b'{}';fs['visual_bible.txt']=b'x'
  fs.update({f'landscape/{i}.png':make_png() for i in range(10)})
  self.assertEqual(len(fs),17)
 def test_30_stage3_parity_count(self):
  fs=fixture_package();fs['visual_plan.json']=b'{}';fs['visual_bible.txt']=b'x'
  for orientation in ('landscape','portrait'):
   fs.update({f'{orientation}/{i}.png':make_png() for i in range(10)})
  self.assertEqual(len(fs),27)
 def test_32_synthetic_three_stage_snapshots_and_resume(self):
  # Mechanical lifecycle only: all synthetic snapshots remain PARTIAL.
  names=['cover','greeting','opening','introduction','development','climax','falling','ending','farewell','outro']
  def rebuild(old, stage):
   payload={k:v for k,v in old.items() if k not in ('manifest.json','validation_report.json')}
   old_report=strict_json(old['validation_report.json']);old_report['stage']=stage
   old_report['remaining_work']=['Real image review, native tokenizer, semantic and timeline validation required']
   payload['validation_report.json']=json.dumps(old_report).encode()
   manifest={'schema_version':'5.0.0','prompt_version':'5.2.2','stage':stage,'status':'PARTIAL','parent_package_sha256':None,'files':[{'path':k,'size_bytes':len(v),'sha256':h(v),'origin_stage':1 if k in ('story.json','image_prompts.json','video_prompts.json') else stage} for k,v in sorted(payload.items())]}
   payload['manifest.json']=json.dumps(manifest).encode();return payload
  s1=fixture_package();zip1=make_zip(s1);self.assertEqual(verify_archive(zip1,s1),s1)
  s2payload={k:v for k,v in s1.items() if k!='manifest.json'}
  s2payload['visual_plan.json']=b'{"schema_version":"4.1.3","image_mode":"ZONE"}'
  s2payload['visual_bible.txt']='Synthetic visual bible'.encode()
  for name in names:s2payload['landscape/'+name+'.png']=make_png()
  s2=rebuild(s2payload,2);zip2=make_zip(s2);verify_archive(zip2,s2);manifest_match(s2)
  self.assertEqual(s2['story.json'],s1['story.json'])
  s3payload={k:v for k,v in s2.items() if k!='manifest.json'}
  for name in names:s3payload['portrait/'+name+'.png']=make_png()
  s3=rebuild(s3payload,3);zip3=make_zip(s3);verify_archive(zip3,s3);manifest_match(s3)
  for name in names:self.assertEqual(s3['landscape/'+name+'.png'],s2['landscape/'+name+'.png'])
  self.assertEqual(len(s1),5);self.assertEqual(len(s2),17);self.assertEqual(len(s3),27)
  self.assertTrue(all(strict_json(s['validation_report.json'])['status']=='PARTIAL' for s in (s1,s2,s3)))
  # Corrupt just one portrait image, then resume keeps all others intact.
  corrupted=dict(s3);corrupted['portrait/climax.png']=b'broken'
  good,missing=resume_good_files(corrupted,s3)
  self.assertEqual(missing,['portrait/climax.png']);self.assertEqual(len(good),26)
  # Persist only synthetic test material, not production story.zip.
  (ROOT/'story_v522_fixture_stage1_PARTIAL.zip').write_bytes(zip1)
  (ROOT/'story_v522_fixture_stage2_PARTIAL.zip').write_bytes(zip2)
  (ROOT/'story_v522_fixture_stage3_PARTIAL.zip').write_bytes(zip3)

 def test_31_tokenizer_not_proven(self):
  # This runner deliberately does NOT claim verified native Chroma1-HD tokenizer.
  self.assertFalse(os.environ.get('VERIFIED_CHROMA1_HD_TOKENIZER'))

if __name__=='__main__':unittest.main(verbosity=2)
