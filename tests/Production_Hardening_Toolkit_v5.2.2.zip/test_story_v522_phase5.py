#!/usr/bin/env python3
"""Phase 5 regression tests, synthetic data only."""
import unittest, copy, json, zipfile, hashlib
from pathlib import Path
from audit_story_v522_phase5 import transition_issues, measured_issues, tokenizer_capability
P=Path(__file__).parent
SP=P/'story_v522_serial_synthetic_fixtures'
A=[json.loads((SP/f'anchor_after_episode_{i}.json').read_text()) for i in range(4)]
with zipfile.ZipFile(P/'story_v522_synthetic_schema_PARTIAL.zip') as z:
 STORY_BYTES=z.read('story.json');VIDEO=json.loads(z.read('video_prompts.json'))

def measured_fixture():
 v=copy.deepcopy(VIDEO);v['timing_basis']='MEASURED';v['timing_config']={'method_id':'ALIGNED_SPAN_TIMING_V1','rate_per_minute':None,'evidence_locator':'user-supplied:synthetic-aligned-spans'}
 story=json.loads(STORY_BYTES);sid={x['id']:x for x in story['script']}
 rows=[];t=0.0
 for c in v['clips']:
  duration=0
  for sp in c['source_spans']:
   txt=sid[sp['script_id']]['text'][sp['start_char']:sp['end_char']];dur=2.0
   rows.append({'clip_id':c['clip_id'],**sp,'text_sha256':hashlib.sha256(txt.encode()).hexdigest(),'start_seconds':t,'end_seconds':t+dur});t+=dur;duration+=dur
  c['estimated_seconds']=duration
 ev={'evidence_version':'phase5-test-1','story_sha256':hashlib.sha256(STORY_BYTES).hexdigest(),'aligned_spans':rows}
 return v,ev

def errors(v,ev,story=STORY_BYTES):return measured_issues(story,v,json.dumps(ev).encode())
class Tests(unittest.TestCase):
 def assertBad(self,items):self.assertTrue(items,'Expected rejection but auditor accepted')
 def test_01_start_transition(self):self.assertEqual([],transition_issues(A[0],A[1],'START'))
 def test_02_continue_transition(self):self.assertEqual([],transition_issues(A[1],A[2],'CONTINUE'))
 def test_03_finalize_transition(self):self.assertEqual([],transition_issues(A[2],A[3],'FINALIZE'))
 def test_04_bad_episode_jump(self):self.assertBad(transition_issues(A[1],A[3]))
 def test_05_deleted_canon(self):
  b=copy.deepcopy(A[2]);b['canon_facts'].pop(0);self.assertBad(transition_issues(A[1],b))
 def test_06_rewrite_canon(self):
  b=copy.deepcopy(A[2]);b['canon_facts'][0]['text']='rewritten';self.assertBad(transition_issues(A[1],b))
 def test_07_authorized_canon_retcon(self):
  b=copy.deepcopy(A[2]);b['canon_facts'][0]['text']='rewritten';self.assertEqual([],transition_issues(A[1],b,authorized_retcons={('canon_facts','f001')}))
 def test_08_missing_summary(self):
  b=copy.deepcopy(A[2]);b['episode_summaries']=b['episode_summaries'][1:];self.assertBad(transition_issues(A[1],b))
 def test_09_modify_summary(self):
  b=copy.deepcopy(A[2]);b['episode_summaries'][0]['summary']='bad';self.assertBad(transition_issues(A[1],b))
 def test_10_erase_character(self):
  b=copy.deepcopy(A[2]);b['characters']=[];self.assertBad(transition_issues(A[1],b))
 def test_11_disappear_open_thread(self):
  b=copy.deepcopy(A[2]);b['open_threads']=[];self.assertBad(transition_issues(A[1],b))
 def test_12_reopen_resolved_thread(self):
  b=copy.deepcopy(A[3]);b['open_threads']=copy.deepcopy(b['resolved_threads']);b['resolved_threads']=[]
  self.assertBad(transition_issues(A[3],b))
 def test_13_mutate_old_clue(self):
  b=copy.deepcopy(A[2]);b['series_state']['clues'][0]['observation']='false';self.assertBad(transition_issues(A[1],b))
 def test_14_remove_old_clue(self):
  b=copy.deepcopy(A[2]);b['series_state']['clues']=b['series_state']['clues'][1:];self.assertBad(transition_issues(A[1],b))
 def test_15_mutate_milestone_contract(self):
  b=copy.deepcopy(A[2]);b['series_state']['milestones'][0]['required']=False;self.assertBad(transition_issues(A[1],b))
 def test_16_mutate_visual_lock(self):
  b=copy.deepcopy(A[2]);b['series_state']['visual_locks'][0]['appearance']='not same';self.assertBad(transition_issues(A[1],b))
 def test_17_bad_finalize(self):
  b=copy.deepcopy(A[3]);b['series_state']['status']='ACTIVE';self.assertBad(transition_issues(A[2],b,'FINALIZE'))
 def test_18_wrong_series(self):
  b=copy.deepcopy(A[2]);b['series_title']='Different';self.assertBad(transition_issues(A[1],b))
 def test_19_valid_measured_evidence(self):
  v,e=measured_fixture();self.assertEqual([],errors(v,e))
 def test_20_missing_evidence_span(self):
  v,e=measured_fixture();e['aligned_spans'].pop();self.assertBad(errors(v,e))
 def test_21_wrong_source_story_sha(self):
  v,e=measured_fixture();e['story_sha256']='0'*64;self.assertBad(errors(v,e))
 def test_22_wrong_text_sha(self):
  v,e=measured_fixture();e['aligned_spans'][0]['text_sha256']='0'*64;self.assertBad(errors(v,e))
 def test_23_wrong_offset(self):
  v,e=measured_fixture();e['aligned_spans'][0]['start_char']=1;self.assertBad(errors(v,e))
 def test_24_wrong_script_id(self):
  v,e=measured_fixture();e['aligned_spans'][0]['script_id']='missing';self.assertBad(errors(v,e))
 def test_25_wrong_clip_id(self):
  v,e=measured_fixture();e['aligned_spans'][0]['clip_id']='notreal';self.assertBad(errors(v,e))
 def test_26_bad_time_order(self):
  v,e=measured_fixture();e['aligned_spans'][0]['end_seconds']=-1;self.assertBad(errors(v,e))
 def test_27_wrong_duration(self):
  v,e=measured_fixture();v['clips'][0]['estimated_seconds']=77;self.assertBad(errors(v,e))
 def test_28_global_overlap(self):
  v,e=measured_fixture();e['aligned_spans'][1]['start_seconds']=0.5;e['aligned_spans'][1]['end_seconds']=2.5;self.assertBad(errors(v,e))
 def test_29_missing_timing_locator(self):
  v,e=measured_fixture();v['timing_config']['evidence_locator']='';self.assertBad(errors(v,e))
 def test_30_wrong_method(self):
  v,e=measured_fixture();v['timing_config']['method_id']='NONE';self.assertBad(errors(v,e))
 def test_31_wrong_evidence_version(self):
  v,e=measured_fixture();e['evidence_version']='bad';self.assertBad(errors(v,e))
 def test_32_legacy_unavailable_not_measured(self):
  _,e=measured_fixture();self.assertBad(errors(VIDEO,e))
 def test_33_tokenizer_unverified(self):self.assertEqual(tokenizer_capability()['gate'],'NOT_CHECKED')
 def test_34_ended_series_cannot_continue(self):
  b=copy.deepcopy(A[3]);b['last_completed_episode']=4;self.assertBad(transition_issues(A[3],b,'CONTINUE'))
if __name__=='__main__':unittest.main(verbosity=2)
