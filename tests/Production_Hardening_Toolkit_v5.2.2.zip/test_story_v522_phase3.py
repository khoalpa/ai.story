import io,json,zipfile,hashlib,unittest,copy,sys,importlib.util
from pathlib import Path
from PIL import Image
import audit_story_v522_phase3 as v
ROOT=Path('/mnt/data')
def dumps(x):return json.dumps(x,ensure_ascii=False,separators=(',',':')).encode('utf-8')
def png(w,h):
 b=io.BytesIO();Image.new('RGB',(w,h),(180,210,190)).save(b,format='PNG');return b.getvalue()
def fixture(stage=3):
 with zipfile.ZipFile(ROOT/'story_v522_fixture_stage1_PARTIAL.zip') as z:story=json.loads(z.read('story.json'))
 story_raw=dumps(story);script=story['script'];ids=[x['character_id'] for x in story['characters']]
 im={'image_prompt_version':'1.1','prompt_version':'5.2.2','source_story':{'schema_version':'4.1.3','sha256':hashlib.sha256(story_raw).hexdigest()},'image_mode':'ZONE','prompt_encoding':{'standard':'T5-512','tokenizer_id':'UNVERIFIED_CANDIDATE','max_tokens':512,'count_scope':'RESOLVED_IMAGE_PROMPT','overflow_policy':'REWRITE'},'style_lock':'warm illustrated story','characters_prompt':'consistent identity','character_locks':[{'character_id':x,'description_lock':'consistent face','planned_reference_path':None} for x in ids], 'assets':[],'limitations':['Native tokenizer unavailable; Stage 1 PARTIAL']}
 plan={'schema_version':'4.1.3','image_mode':'ZONE','reference_mode':'DESCRIPTION_ONLY','targets':{'landscape':{'size_policy':'MODEL_DEFAULT','preferred_aspect_ratio':'16:9','width':None,'height':None},'portrait':{'size_policy':'MODEL_DEFAULT','preferred_aspect_ratio':'9:16','width':None,'height':None}},'characters':[],'assets':[]}
 for i,b in enumerate(v.ZONE):
  role=b[:-4].upper();selected=[s['id'] for s in script if s['zone']==role]
  # synthetic asset map: empty character ids by design, no character depicted in fixture imagery
  a={'basename':b,'role':role,'source_script_ids':selected,'character_ids':[],'brief':'Illustration prompt '+b,'landscape_prompt':'One scene landscape','portrait_prompt':'One scene portrait'}
  p={'asset_id':f'a{i+1:03}',**a,'must_show':[],'must_avoid':[]};im['assets'].append(p);plan['assets'].append(a)
 clips=[]
 for i,s in enumerate(script):
  clips.append({'clip_id':f'clip_{i+1:04}','source_spans':[{'script_id':s['id'],'start_char':0,'end_char':len(s['text'])}],'estimated_seconds':None,'aspect_ratio':'16:9','reference_paths':[],'prompt':'Visual shot','narration':s['text'],'audio_note':'none','transition':'cut'})
 video={'schema_version':'4.1.3','source_mode':'STORY_ONLY','target_model':None,'coverage':'FULL_STORY','timing_basis':'UNAVAILABLE','timing_config':{'method_id':'NONE','rate_per_minute':None,'evidence_locator':None},'clips':clips,'limitations':['Synthetic timing unavailable']}
 report={'schema_version':'5.0.0','prompt_version':'5.2.2','stage':stage,'status':'PARTIAL','input_sources':['synthetic validation fixture'], 'checks':[], 'limitations':['Not a production package'], 'remaining_work':['Verified pipeline tokenizer and model review'], 'archive_validation':{'status':'NOT_CHECKED','details':'Archive validation after pack'}}
 raw={'story.json':story_raw,'image_prompts.json':dumps(im),'video_prompts.json':dumps(video),'validation_report.json':dumps(report)}
 if stage>=2:
  raw['visual_plan.json']=dumps(plan);raw['visual_bible.txt']=b'visual style reference fixture'
  for b in v.ZONE:raw['landscape/'+b]=png(320,180)
 if stage>=3:
  for b in v.ZONE:raw['portrait/'+b]=png(180,320)
 manifest={'schema_version':'5.0.0','prompt_version':'5.2.2','stage':stage,'status':'PARTIAL','parent_package_sha256':None, 'files':[{'path':p,'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'origin_stage':1 if p in ['story.json','image_prompts.json','video_prompts.json'] else (3 if p.startswith('portrait/') else (2 if p.startswith('landscape/') or p.startswith('visual_') else stage))} for p,b in sorted(raw.items())]}
 raw['manifest.json']=dumps(manifest)
 return raw

def make_zip(raw,path):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for p,b in raw.items():z.writestr(p,b)
class TestPhase3(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.fixture=fixture();cls.path=ROOT/'story_v522_synthetic_schema_PARTIAL.zip';make_zip(cls.fixture,cls.path)
 def assertIssue(self,raw,fragment):
  a=v.Audit();a.package(raw)
  self.assertTrue(any(fragment in x['path'] for x in a.issues), f'Missing expected detection {fragment}, observed {a.issues[:8]}')
 def test01_good_synthetic_stage1(self):self.assertEqual(v.Audit().package(fixture(1)),[])
 def test02_good_synthetic_stage2(self):self.assertEqual(v.Audit().package(fixture(2)),[])
 def test03_good_synthetic_stage3(self):self.assertEqual(v.Audit().package(fixture(3)),[])
 def test04_good_zip(self):self.assertEqual(v.audit_zip(self.path)['issue_count'],0)
 def test05_old_fixtures_rejected(self):
  for n in [1,2,3]:self.assertGreater(v.audit_zip(ROOT/f'story_v522_fixture_stage{n}_PARTIAL.zip')['issue_count'],0)
 def test06_missing_image_prompt_key(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['image_prompts.json']);del y['prompt_encoding'];x['image_prompts.json']=dumps(y);self.assertIssue(x,'image_prompts.prompt_encoding')
 def test07_bad_source_binding(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['image_prompts.json']);y['source_story']['sha256']='0'*64;x['image_prompts.json']=dumps(y);self.assertIssue(x,'image_prompts.source_story.sha256')
 def test08_invalid_video_span(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['video_prompts.json']);y['clips'][0]['source_spans'][0]['end_char']=99999;x['video_prompts.json']=dumps(y);self.assertIssue(x,'video.clips[0].source_spans[0]')
 def test09_invalid_narration(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['video_prompts.json']);y['clips'][0]['narration']='Changed';x['video_prompts.json']=dumps(y);self.assertIssue(x,'video.clips[0].narration')
 def test10_invalid_manifest_hash(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['manifest.json']);y['files'][0]['sha256']='0'*64;x['manifest.json']=dumps(y);self.assertIssue(x,'manifest.files.')
 def test11_wrong_orientation_image(self):
  x=copy.deepcopy(self.fixture);x['landscape/cover.png']=png(180,320);self.assertIssue(x,'landscape/cover.png')
 def test12_missing_png(self):
  x=copy.deepcopy(self.fixture);del x['portrait/cover.png'];self.assertIssue(x,'portrait/cover.png')
 def test13_corrupt_image(self):
  x=copy.deepcopy(self.fixture);x['portrait/cover.png']=b'not-png';self.assertIssue(x,'portrait/cover.png')
 def test14_unknown_plan_key(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['visual_plan.json']);y['invented']='x';x['visual_plan.json']=dumps(y);self.assertIssue(x,'visual_plan.invented')
 def test15_unavailable_timing_mismatch(self):
  x=copy.deepcopy(self.fixture);y=json.loads(x['video_prompts.json']);y['clips'][0]['estimated_seconds']=4.0;x['video_prompts.json']=dumps(y);self.assertIssue(x,'video.clips[0].estimated_seconds')
 def test16_duplicate_raw_key(self):
  with self.assertRaisesRegex(ValueError,'Duplicate'):v.strict_load(b'{"a":1,"a":2}')
 def test17_duplicate_nfc_key(self):
  with self.assertRaisesRegex(ValueError,'Duplicate'):v.strict_load('{"é":1,"é":2}'.encode('utf-8'))
 def test18_nan_rejected(self):
  with self.assertRaisesRegex(ValueError,'Non-finite'):v.strict_load(b'{"x":NaN}')
 def test19_unpaired_surrogate(self):
  with self.assertRaisesRegex(ValueError,'surrogate'):v.strict_load(b'{"x":"\\ud800"}')
 def test20_unsafe_zip_member(self):
  f=ROOT/'story_v522_unsafe_negative_test.zip'
  with zipfile.ZipFile(f,'w') as z:z.writestr('../danger.txt',b'x')
  self.assertGreater(v.audit_zip(f)['issue_count'],0);f.unlink()
if __name__=='__main__':unittest.main(verbosity=2)
