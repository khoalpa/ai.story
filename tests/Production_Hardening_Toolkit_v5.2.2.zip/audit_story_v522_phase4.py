#!/usr/bin/env python3
"""Phase 4 additional checks for v5.2.2; never certifies semantic/image/tokenizer gates."""
import json,zipfile,io,math,re,argparse
from pathlib import Path
from audit_story_v522_phase3 import Audit, strict_load
ZONES=['GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL']
CASE_TYPES={'MISSING_PERSON','IDENTITY_DISPUTE','OWNERSHIP_PROVENANCE_DISPUTE','CONCEALED_HARM','WITNESS_CREDIBILITY_CASE','UNEXPLAINED_EVENT','OTHER'}
class Phase4(Audit):
 def unique(self,seq,w):self.check(len(seq)==len(set(seq)),w,'Duplicate values')
 def strings(self,seq,w):
  v=self.array(seq,w)
  for i,x in enumerate(v):self.string(x,f'{w}[{i}]')
  return v
 def anchor(self,a,story=None):
  w='series_anchor'
  if not self.exact(a,['schema_version','series_title','last_completed_episode','characters','canon_facts','open_threads','resolved_threads','episode_summaries','series_state'],w):return
  self.check(a['schema_version']=='4.1.3',w+'.schema_version','Invalid schema version');self.string(a['series_title'],w+'.series_title')
  n=a['last_completed_episode'];self.integer(n,w+'.last_completed_episode');n=n if type(n)==int and n>=0 else 0
  ids=[];threads=[]
  for i,c in enumerate(self.array(a['characters'],w+'.characters')):
   p=f'{w}.characters[{i}]'
   if self.exact(c,['character_id','name','established_facts','known_facts'],p):
    self.string(c['character_id'],p+'.character_id');self.string(c['name'],p+'.name');ids.append(c['character_id'])
    self.strings(c['established_facts'],p+'.established_facts');self.strings(c['known_facts'],p+'.known_facts')
  self.unique(ids,w+'.characters');facts=[]
  for i,c in enumerate(self.array(a['canon_facts'],w+'.canon_facts')):
   p=f'{w}.canon_facts[{i}]'
   if self.exact(c,['fact_id','text','established_episode'],p):
    self.string(c['fact_id'],p+'.fact_id');facts.append(c['fact_id']);self.string(c['text'],p+'.text');self.integer(c['established_episode'],p+'.established_episode',1)
    self.check(type(c['established_episode'])==int and c['established_episode']<=n,p+'.established_episode','Episode exceeds completed count')
  self.unique(facts,w+'.canon_facts')
  for label in ['open_threads','resolved_threads']:
   for i,c in enumerate(self.array(a[label],w+'.'+label)):
    p=f'{w}.{label}[{i}]'
    if self.exact(c,['thread_id','description','clues'],p):
     self.string(c['thread_id'],p+'.thread_id');threads.append(c['thread_id']);self.string(c['description'],p+'.description');self.strings(c['clues'],p+'.clues')
  self.unique(threads,w+'.threads_union')
  summ=self.array(a['episode_summaries'],w+'.episode_summaries')
  for i,c in enumerate(summ):
   p=f'{w}.episode_summaries[{i}]'
   if self.exact(c,['episode','summary'],p):self.check(c['episode']==i+1,p+'.episode','Episode summary must be sequential');self.string(c['summary'],p+'.summary')
  self.check(len(summ)==n,w+'.episode_summaries','Missing historical summaries')
  if story:
   self.check(story.get('meta',{}).get('series')==a['series_title'],w+'.series_title','Story/anchor series mismatch')
   self.check(story.get('meta',{}).get('episode')==n,w+'.last_completed_episode','Story/anchor episode mismatch')
  s=a['series_state'];p=w+'.series_state'
  if not self.exact(s,['status','next_episode_contract','milestones','clues','consequences','visual_locks','episode_designs'],p):return
  self.enum(s['status'],['ACTIVE','COMPLETED','UNKNOWN'],p+'.status')
  contract=s['next_episode_contract']
  if s['status']=='COMPLETED':self.check(contract is None,p+'.next_episode_contract','COMPLETED requires null contract')
  if s['status']=='ACTIVE' and n>=1:self.check(contract is not None,p+'.next_episode_contract','ACTIVE output requires contract')
  if contract is not None and self.exact(contract,['episode','premise','required_thread_ids','forbidden_resolutions'],p+'.next_episode_contract'):
   self.check(contract['episode']==n+1,p+'.next_episode_contract.episode','Contract episode must be next');self.string(contract['premise'],p+'.next_episode_contract.premise')
   r=self.strings(contract['required_thread_ids'],p+'.next_episode_contract.required_thread_ids');self.unique(r,p+'.next_episode_contract.required_thread_ids')
   open_ids={x.get('thread_id') for x in a['open_threads'] if isinstance(x,dict)}
   for t in r:self.check(t in open_ids,p+'.next_episode_contract.required_thread_ids','Contract refers to non-open thread')
   q=self.strings(contract['forbidden_resolutions'],p+'.next_episode_contract.forbidden_resolutions');self.unique(q,p+'.next_episode_contract.forbidden_resolutions')
  milestone_ids=[]
  for i,m in enumerate(self.array(s['milestones'],p+'.milestones')):
   w2=f'{p}.milestones[{i}]'
   if not self.exact(m,['milestone_id','description','target_episode','required','status','resolution'],w2):continue
   self.string(m['milestone_id'],w2+'.milestone_id');milestone_ids.append(m['milestone_id']);self.string(m['description'],w2+'.description')
   if m['target_episode'] is not None:self.integer(m['target_episode'],w2+'.target_episode',1)
   self.check(type(m['required'])==bool,w2+'.required','Must be boolean');self.enum(m['status'],['PLANNED','FULFILLED','CANCELLED'],w2+'.status')
   self.check(m['resolution'] is None if m['status']=='PLANNED' else isinstance(m['resolution'],str) and bool(m['resolution'].strip()),w2+'.resolution','Resolution/status conflict')
   if s['status']=='COMPLETED' and m['required'] is True:self.check(m['status']!='PLANNED',w2+'.status','COMPLETED still has required PLANNED milestone')
  self.unique(milestone_ids,p+'.milestones')
  clues=[];story_ids={x['id'] for x in story['script']} if story else set()
  for i,c in enumerate(self.array(s['clues'],p+'.clues')):
   w2=f'{p}.clues[{i}]'
   if not self.exact(c,['clue_id','thread_id','observation','interpretation','status','introduced_episode','revealed_episode','known_by','source_script_ids'],w2):continue
   self.string(c['clue_id'],w2+'.clue_id');clues.append(c['clue_id']);self.check(c['thread_id'] in threads,w2+'.thread_id','Unknown thread');self.string(c['observation'],w2+'.observation')
   if c['interpretation'] is not None:self.string(c['interpretation'],w2+'.interpretation')
   self.enum(c['status'],['UNRESOLVED','VERIFIED','REFUTED'],w2+'.status')
   ep=c['introduced_episode'];self.integer(ep,w2+'.introduced_episode',1);self.check(type(ep)==int and ep<=n,w2+'.introduced_episode','Future introduction')
   rev=c['revealed_episode'];self.check(rev is None if c['status']=='UNRESOLVED' else type(rev)==int and type(ep)==int and ep<=rev<=n,w2+'.revealed_episode','Revealed/status/episode conflict')
   known=self.strings(c['known_by'],w2+'.known_by');self.unique(known,w2+'.known_by')
   for cid in known:self.check(cid in ids,w2+'.known_by','Unknown character')
   loc=self.strings(c['source_script_ids'],w2+'.source_script_ids');self.check(bool(loc),w2+'.source_script_ids','Empty source locator');self.unique(loc,w2+'.source_script_ids')
   if story and ep==n:
    for l in loc:self.check(l in story_ids,w2+'.source_script_ids','Unknown current episode script locator')
  self.unique(clues,p+'.clues')
  cons=[]
  for i,c in enumerate(self.array(s['consequences'],p+'.consequences')):
   w2=f'{p}.consequences[{i}]'
   if not self.exact(c,['consequence_id','description','established_episode','status','resolution'],w2):continue
   self.string(c['consequence_id'],w2+'.consequence_id');cons.append(c['consequence_id']);self.string(c['description'],w2+'.description')
   self.integer(c['established_episode'],w2+'.established_episode',1);self.check(type(c['established_episode'])==int and c['established_episode']<=n,w2+'.established_episode','Future consequence')
   self.enum(c['status'],['ACTIVE','RESOLVED'],w2+'.status');self.check(c['resolution'] is None if c['status']=='ACTIVE' else isinstance(c['resolution'],str) and bool(c['resolution'].strip()),w2+'.resolution','Resolution/status conflict')
  self.unique(cons,p+'.consequences')
  locked=[]
  for i,c in enumerate(self.array(s['visual_locks'],p+'.visual_locks')):
   w2=f'{p}.visual_locks[{i}]'
   if not self.exact(c,['character_id','appearance','wardrobe','props'],w2):continue
   self.check(c['character_id'] in ids,w2+'.character_id','Unknown character');locked.append(c['character_id']);self.string(c['appearance'],w2+'.appearance');self.string(c['wardrobe'],w2+'.wardrobe');self.strings(c['props'],w2+'.props')
  self.unique(locked,p+'.visual_locks')
  designs=[]
  for i,c in enumerate(self.array(s['episode_designs'],p+'.episode_designs')):
   w2=f'{p}.episode_designs[{i}]'
   if not self.exact(c,['episode','central_question','case_type','clue_media','decisive_choice','ending_consequence'],w2):continue
   ep=c['episode'];self.integer(ep,w2+'.episode',1);self.check(type(ep)==int and ep<=n,w2+'.episode','Future design episode');designs.append(ep)
   for k in ['central_question','decisive_choice','ending_consequence']:self.string(c[k],w2+'.'+k)
   self.enum(c['case_type'],CASE_TYPES,w2+'.case_type');self.strings(c['clue_media'],w2+'.clue_media')
  self.check(designs==sorted(set(designs)),p+'.episode_designs','Design episode IDs must be unique and sorted')
  if n>0:self.check(n in designs,p+'.episode_designs','Missing current episode design')
 def bindings(self,story,plan,ip):
  p='visual_plan.assets';scripts=story['script'];order={s['id']:i for i,s in enumerate(scripts)}
  zp={z:[s['id'] for s in scripts if s['zone']==z] for z in ZONES}
  scene_ids=[]
  for sc in story['outline']:
   group=[s['id'] for s in scripts if s['scene_id']==sc['scene_id'] and s['zone'] in ZONES[1:-1]]
   if group:scene_ids.append(group)
  for i,a in enumerate(plan['assets']):
   w=f'{p}[{i}]';base=a['basename'];ids=a['source_script_ids'];self.unique(ids,w+'.source_script_ids');self.unique(a['character_ids'],w+'.character_ids')
   self.check(ids==sorted(ids,key=lambda x:order.get(x,10**9)),w+'.source_script_ids','Source IDs out of script order')
   if base not in ('cover.png','outro.png'):self.check(bool(ids),w+'.source_script_ids','Non-cover/outro asset has no source')
   if plan['image_mode']=='ZONE' and a['role'] in zp:self.check(ids==zp[a['role']],w+'.source_script_ids','ZONE source mapping mismatch')
   if plan['image_mode']=='SCENE':
    if a['role']=='SCENE':
     ix=int(base.split('_')[1].split('.')[0])-1 if re.fullmatch(r'scene_\d{4}\.png',base) else -1
     self.check(0<=ix<len(scene_ids) and ids==scene_ids[ix],w+'.source_script_ids','SCENE source mapping mismatch')
    elif a['role'] in ('GREETING','FAREWELL'):self.check(ids==zp[a['role']],w+'.source_script_ids','SCENE framing mapping mismatch')
   self.check(a['role']==('SCENE' if base.startswith('scene_') else base[:-4].upper()),w+'.role','Role/basename mismatch')
   ia=ip['assets'][i]
   for k in ['role','source_script_ids','character_ids']:
    self.check(a[k]==ia[k],w+'.'+k,'Image prompt/visual plan binding mismatch')
 def timing(self,story,video):
  p='video';basis=video['timing_basis'];cfg=video['timing_config'];clips=video['clips'];lang=story['meta']['language'].lower()
  if basis=='UNAVAILABLE':
   self.check(cfg=={'method_id':'NONE','rate_per_minute':None,'evidence_locator':None},p+'.timing_config','UNAVAILABLE timing config must be NONE/null/null')
   for i,c in enumerate(clips):self.check(c['estimated_seconds'] is None,f'{p}.clips[{i}].estimated_seconds','UNAVAILABLE duration must be null')
   return
  if basis=='MEASURED':
   self.check(cfg['method_id']=='ALIGNED_SPAN_TIMING_V1' and cfg['rate_per_minute'] is None and isinstance(cfg['evidence_locator'],str) and bool(cfg['evidence_locator'].strip()),p+'.timing_config','MEASURED needs aligned evidence')
   self.check(all(type(c['estimated_seconds']) in (int,float) and c['estimated_seconds']>0 for c in clips),p+'.clips','Invalid measured durations')
   return # cannot certify alignment/evidence without the source
  if basis!='ESTIMATED':self.fail(p+'.timing_basis','Invalid timing basis');return
  if lang not in ['vi','en'] or cfg['method_id']!='WHITESPACE_RATE_V1':return # custom estimators need independent evidence
  rate=cfg['rate_per_minute'];self.check(type(rate) in (float,int) and rate>0,p+'.timing_config.rate_per_minute','Invalid words/minute')
  self.check(cfg['evidence_locator'] is None,p+'.timing_config.evidence_locator','WHITESPACE method must not have locator')
  if type(rate) not in (int,float) or rate<=0:return
  indexed={s['id']:s for s in story['script']};tot=0.0
  for i,c in enumerate(clips):
   exp=0.0
   for span in c['source_spans']:
    item=indexed.get(span['script_id']);
    if item is None:continue
    txt=item['text'][span['start_char']:span['end_char']];exp+=len(txt.split())*60/(rate*item['speed'])
    if span['end_char']==len(item['text']):exp+=item['pause_ms']/1000
   tot+=exp
   self.check(type(c['estimated_seconds']) in (int,float) and abs(c['estimated_seconds']-round(exp,2))<=0.020001,f'{p}.clips[{i}].estimated_seconds','Wrong estimated duration')
  self.check(abs(sum(c['estimated_seconds'] for c in clips)-tot)<=0.005*len(clips)+1e-6,p+'.clips','Total rounding discrepancy')
 def report(self,report,stage):
  p='report';checks=report['checks'];seen=[]
  for i,c in enumerate(checks):
   w=f'{p}.checks[{i}]';seen.append(c.get('id'))
   if not isinstance(c,dict):self.fail(w,'Not an object');continue
   self.string(c.get('id'),w+'.id');self.enum(c.get('status'),['PASS','FAIL','NOT_CHECKED','NOT_APPLICABLE'],w+'.status')
   self.enum(c.get('method'),['CODE','TOOL','MODEL_REVIEW'],w+'.method');self.check(type(c.get('required'))==bool,w+'.required','required must be boolean')
   self.string(c.get('target'),w+'.target');self.string(c.get('details'),w+'.details')
  self.unique(seen,p+'.checks.id')
  if report['status']=='COMPLETE':
   self.check(bool(checks),p+'.checks','COMPLETE must have checks')
   for i,c in enumerate(checks):
    if c.get('required') is True:self.check(c.get('status') in ('PASS','NOT_APPLICABLE'),f'{p}.checks[{i}].status','Required check incomplete')
   needed={'STORY_NOVELTY','IMAGE_PROMPT_T5_TOKENS','VIDEO_TIMING','SCHEMA_LINKS','FILE_SET','MANIFEST_MATCH','STORY_CRAFT'}
   if stage>=2:needed.update(['VISUAL_PLAN','IMAGE_FILES','IMAGE_CONTENT','INHERITED_BYTES'])
   if stage>=3:needed.add('ORIENTATION_PARITY')
   names={c['id'] for c in checks if isinstance(c,dict)}
   for key in needed:self.check(key in names,p+'.checks','COMPLETE missing required gate '+key)
 def evaluate(self,raw):
  base=Audit();base.package(raw);self.issues=list(base.issues)
  try:
   story=strict_load(raw['story.json']);ip=strict_load(raw['image_prompts.json']);video=strict_load(raw['video_prompts.json']);report=strict_load(raw['validation_report.json']);manifest=strict_load(raw['manifest.json'])
   if 'series_anchor.json' in raw:self.anchor(strict_load(raw['series_anchor.json']),story)
   if manifest['stage']>=2 and 'visual_plan.json' in raw:self.bindings(story,strict_load(raw['visual_plan.json']),ip)
   self.timing(story,video);self.report(report,manifest['stage'])
  except Exception as e:self.fail('phase4.execution','Could not finish additional checks: '+repr(e))
  return self.issues

def readzip(path):
 with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('archive');a=ap.parse_args();issues=Phase4().evaluate(readzip(a.archive));print(json.dumps({'issues':issues,'count':len(issues)},ensure_ascii=False,indent=2));raise SystemExit(bool(issues))
