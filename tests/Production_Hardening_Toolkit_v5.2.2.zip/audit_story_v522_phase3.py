#!/usr/bin/env python3
"""Independent, strict structural and linkage audit for v5.2.2.
Does not claim semantic review, native tokenization, or full production certification.
"""
import argparse,copy,hashlib,io,json,os,re,sys,unicodedata,zipfile
from pathlib import Path
from PIL import Image
HEX=re.compile(r'^[a-f0-9]{64}$'); CHAR=re.compile(r'^c\d{3}$'); SCRIPT=re.compile(r'^s\d{4}$')
ZONE=['cover.png','greeting.png','opening.png','introduction.png','development.png','climax.png','falling.png','ending.png','farewell.png','outro.png']
class Audit:
 def __init__(self):self.issues=[];self.stats={}
 def fail(self,where,msg):self.issues.append({'path':where,'issue':msg})
 def check(self,ok,where,msg):
  if not ok:self.fail(where,msg)
 def exact(self,obj,keys,where):
  if not isinstance(obj,dict):self.fail(where,'Expected object');return False
  for k in sorted(set(keys)-set(obj)):self.fail(where+'.'+k,'Missing required key')
  for k in sorted(set(obj)-set(keys)):self.fail(where+'.'+k,'Unknown key (closed schema)')
  return set(obj)==set(keys)
 def string(self,v,w,nullable=False):self.check((v is None and nullable) or (isinstance(v,str) and bool(v.strip())),w,'Expected nonempty string'+(' or null' if nullable else ''))
 def enum(self,v,options,w):self.check(v in options if isinstance(v,str) else False,w,'Invalid enum')
 def integer(self,v,w,minimum=0):self.check(type(v)==int and v>=minimum,w,'Invalid integer')
 def number(self,v,w,positive=True):self.check(type(v) in (int,float) and (not positive or v>0),w,'Invalid number')
 def array(self,v,w):
  if not isinstance(v,list):self.fail(w,'Expected array');return []
  return v
 def entries(self,items,keys,where):
  for i,item in enumerate(self.array(items,where)):self.exact(item,keys,f'{where}[{i}]')
 def story(self,d):
  if not self.exact(d,['schema_version','meta','characters','outline','script'],'story'):return
  self.check(d['schema_version']=='4.1.3','story.schema_version','Expected 4.1.3')
  m=d['meta'];mk=['title','series','episode','author','channel','profile','age_band','language','genre','tone','target_minutes','estimated_minutes','timing_method','tags']
  if self.exact(m,mk,'story.meta'):
   self.enum(m['profile'],['YOUTH_SAFE','ADULT_STANDARD','SERIAL_DETECTIVE'],'meta.profile')
   for k in ['title','author','channel','language','genre','tone','timing_method']:self.string(m[k],'meta.'+k)
   self.integer(m['episode'],'meta.episode',1);self.number(m['target_minutes'],'meta.target_minutes')
   if m['estimated_minutes'] is not None:self.number(m['estimated_minutes'],'meta.estimated_minutes')
   self.check(m['series'] is None or isinstance(m['series'],str) and bool(m['series']),'meta.series','Invalid series')
   self.check((m['age_band']=='18+' if m['profile']!='YOUTH_SAFE' else m['age_band'] in ['3-6','7-10','11-14','15-18']),'meta.age_band','Invalid age_band')
   self.check(all(isinstance(x,str) and x.strip() for x in self.array(m['tags'],'meta.tags')),'meta.tags','Invalid tag')
  chars=self.array(d['characters'],'story.characters');scenes=self.array(d['outline'],'story.outline');scripts=self.array(d['script'],'story.script')
  self.check(bool(chars),'story.characters','Must not be empty');self.check(bool(scenes),'story.outline','Must not be empty');self.check(bool(scripts),'story.script','Must not be empty')
  cid=set(); sid=set(); seen_scene=[]
  for i,c in enumerate(chars):
   w=f'characters[{i}]'
   if not self.exact(c,['character_id','name','age','role','appearance','personality','voice_note'],w):continue
   self.check(isinstance(c['character_id'],str) and bool(CHAR.fullmatch(c['character_id'])),w+'.character_id','Invalid ID')
   self.check(c['character_id'] not in cid,w+'.character_id','Duplicate ID');cid.add(c['character_id'])
   for k in ['name','role','appearance','personality','voice_note']:self.string(c[k],w+'.'+k)
   if c['age'] is not None:self.integer(c['age'],w+'.age')
  for i,s in enumerate(scenes):
   w=f'outline[{i}]'
   if not self.exact(s,['scene_id','summary','change','setup_or_payoff'],w):continue
   self.check(s['scene_id']==f'sc{i+1:03}',w+'.scene_id','Nonsequential scene ID');sid.add(s['scene_id'])
   for k in ['summary','change']:self.string(s[k],w+'.'+k)
  for i,s in enumerate(scripts):
   w=f'script[{i}]'
   if not self.exact(s,['id','zone','scene_id','speaker','text','emotion','speed','pause_ms','ambience'],w):continue
   self.check(s['id']==f's{i+1:04}',w+'.id','Nonsequential script ID')
   self.check(s['scene_id'] in sid,w+'.scene_id','Dangling scene ID')
   self.check(s['speaker']=='narrator' or s['speaker'] in cid,w+'.speaker','Dangling speaker')
   self.string(s['text'],w+'.text');self.number(s['speed'],w+'.speed');self.integer(s['pause_ms'],w+'.pause_ms')
   self.enum(s['zone'],['GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL','OUTRO'],w+'.zone')
   if not seen_scene or seen_scene[-1]!=s['scene_id']:
    self.check(s['scene_id'] not in seen_scene,w+'.scene_id','Noncontiguous scene');seen_scene.append(s['scene_id'])
  self.check(seen_scene==[s.get('scene_id') for s in scenes],'script.scene_sequence','Scenes missing or out of order')
 def image_prompts(self,d,story_raw,story):
  keys=['image_prompt_version','prompt_version','source_story','image_mode','prompt_encoding','style_lock','characters_prompt','character_locks','assets','limitations']
  if not self.exact(d,keys,'image_prompts'):return
  self.check(d['image_prompt_version']=='1.1','image_prompts.version','Expected 1.1')
  self.check(d['prompt_version']=='5.2.2','image_prompts.prompt_version','Expected 5.2.2')
  self.enum(d['image_mode'],['ZONE','SCENE'],'image_prompts.image_mode')
  ss=d['source_story'];self.exact(ss,['schema_version','sha256'],'image_prompts.source_story')
  if isinstance(ss,dict):
   self.check(ss.get('schema_version')=='4.1.3','image_prompts.source_story.schema_version','Invalid version')
   self.check(ss.get('sha256')==hashlib.sha256(story_raw).hexdigest(),'image_prompts.source_story.sha256','Story binding mismatch')
  en=d['prompt_encoding'];self.exact(en,['standard','tokenizer_id','max_tokens','count_scope','overflow_policy'],'image_prompts.prompt_encoding')
  if isinstance(en,dict):
   for k,value in [('standard','T5-512'),('max_tokens',512),('count_scope','RESOLVED_IMAGE_PROMPT'),('overflow_policy','REWRITE')]:self.check(en.get(k)==value,'image_prompts.prompt_encoding.'+k,'Wrong encoding contract')
   self.string(en.get('tokenizer_id'),'image_prompts.prompt_encoding.tokenizer_id')
  self.string(d['style_lock'],'image_prompts.style_lock');self.string(d['characters_prompt'],'image_prompts.characters_prompt')
  locks=self.array(d['character_locks'],'image_prompts.character_locks');story_ids={x.get('character_id') for x in story.get('characters',[]) if isinstance(x,dict)};lock_ids=set()
  for i,l in enumerate(locks):
   w=f'image_prompts.character_locks[{i}]'
   if not self.exact(l,['character_id','description_lock','planned_reference_path'],w):continue
   cid=l['character_id'];self.check(cid in story_ids and cid not in lock_ids,w+'.character_id','Missing/duplicate character');lock_ids.add(cid)
   self.string(l['description_lock'],w+'.description_lock')
   self.check(l['planned_reference_path'] is None or l['planned_reference_path']==f'characters/{cid}.png',w+'.planned_reference_path','Invalid reference path')
  assets=self.array(d['assets'],'image_prompts.assets');self.check(bool(assets),'image_prompts.assets','Empty assets');bases=[];aids=set()
  script_ids={x.get('id') for x in story.get('script',[]) if isinstance(x,dict)}
  for i,a in enumerate(assets):
   w=f'image_prompts.assets[{i}]'
   if not self.exact(a,['asset_id','basename','role','source_script_ids','character_ids','brief','landscape_prompt','portrait_prompt','must_show','must_avoid'],w):continue
   self.string(a['asset_id'],w+'.asset_id');self.check(a['asset_id'] not in aids,w+'.asset_id','Duplicate asset ID');aids.add(a['asset_id'])
   bases.append(a['basename']);self.check(isinstance(a['basename'],str) and bool(re.fullmatch(r'[a-z0-9_]+\.png',a['basename'])),w+'.basename','Invalid basename')
   self.enum(a['role'],['COVER','GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL','OUTRO','SCENE'],w+'.role')
   for k in ['brief','landscape_prompt','portrait_prompt']:self.string(a[k],w+'.'+k)
   for x in self.array(a['source_script_ids'],w+'.source_script_ids'):self.check(x in script_ids,w+'.source_script_ids','Unknown script ID')
   for x in self.array(a['character_ids'],w+'.character_ids'):self.check(x in lock_ids,w+'.character_ids','Unknown lock ID')
   for k in ['must_show','must_avoid']:self.check(isinstance(a[k],list),w+'.'+k,'Expected array')
  if d['image_mode']=='ZONE':self.check(bases==ZONE,'image_prompts.assets','ZONE basename list mismatch')
  else:self.check(bases[:2]==ZONE[:2] and bases[-2:]==ZONE[-2:] and bases[2:-2]==[f'scene_{i:04}.png' for i in range(1,len(bases)-3)],'image_prompts.assets','SCENE basename list mismatch')
  self.array(d['limitations'],'image_prompts.limitations')
 def video(self,d,story):
  if not self.exact(d,['schema_version','source_mode','target_model','coverage','timing_basis','timing_config','clips','limitations'],'video_prompts'):return
  self.check(d['schema_version']=='4.1.3','video.schema_version','Wrong version');self.check(d['source_mode']=='STORY_ONLY','video.source_mode','Wrong source_mode')
  self.enum(d['coverage'],['FULL_STORY','KEY_SCENES'],'video.coverage');self.enum(d['timing_basis'],['ESTIMATED','MEASURED','UNAVAILABLE'],'video.timing_basis')
  self.check(d['target_model'] is None or isinstance(d['target_model'],str),'video.target_model','Invalid target model')
  cfg=d['timing_config'];self.exact(cfg,['method_id','rate_per_minute','evidence_locator'],'video.timing_config')
  if isinstance(cfg,dict):
   if d['timing_basis']=='UNAVAILABLE':self.check(cfg=={'method_id':'NONE','rate_per_minute':None,'evidence_locator':None},'video.timing_config','UNAVAILABLE config mismatch')
   if d['timing_basis']=='ESTIMATED' and story.get('meta',{}).get('language') in ['vi','en']:
    self.check(cfg.get('method_id')=='WHITESPACE_RATE_V1' and type(cfg.get('rate_per_minute')) in [int,float] and cfg['rate_per_minute']>0 and cfg.get('evidence_locator') is None,'video.timing_config','Invalid vi/en estimate')
  clips=self.array(d['clips'],'video.clips');self.check(bool(clips),'video.clips','Empty clips');script={x.get('id'):x for x in story.get('script',[]) if isinstance(x,dict)}; coverage={k:[] for k in script}
  for i,c in enumerate(clips):
   w=f'video.clips[{i}]'
   if not self.exact(c,['clip_id','source_spans','estimated_seconds','aspect_ratio','reference_paths','prompt','narration','audio_note','transition'],w):continue
   self.check(c['clip_id']==f'clip_{i+1:04}',w+'.clip_id','Nonsequential clip ID')
   self.enum(c['aspect_ratio'],['16:9','9:16'],w+'.aspect_ratio');self.string(c['prompt'],w+'.prompt')
   self.check(c['reference_paths']==[],w+'.reference_paths','Must be empty for stage 1')
   if d['timing_basis']=='UNAVAILABLE':self.check(c['estimated_seconds'] is None,w+'.estimated_seconds','Must be null')
   else:self.number(c['estimated_seconds'],w+'.estimated_seconds')
   parts=[]
   for j,s in enumerate(self.array(c['source_spans'],w+'.source_spans')):
    p=f'{w}.source_spans[{j}]'
    if not self.exact(s,['script_id','start_char','end_char'],p):continue
    sid=s['script_id'];self.check(sid in script,p+'.script_id','Unknown script id')
    if sid in script and type(s['start_char'])==int and type(s['end_char'])==int:
     txt=script[sid]['text'];start,end=s['start_char'],s['end_char'];self.check(0<=start<end<=len(txt),p,'Invalid span bounds')
     if 0<=start<end<=len(txt):coverage[sid].append((start,end));parts.append(txt[start:end])
   self.check(c['narration']==' '.join(parts),w+'.narration','Narration mismatch')
  if d['coverage']=='FULL_STORY':
   for sid,s in script.items():
    intervals=sorted(coverage[sid]);self.check(intervals and intervals[0][0]==0 and intervals[-1][1]==len(s['text']) and all(intervals[j][1]==intervals[j+1][0] for j in range(len(intervals)-1)),f'video.coverage.{sid}','Not exact full coverage')
  self.array(d['limitations'],'video.limitations')
 def visual_plan(self,d,story,im,raw,stage):
  if not self.exact(d,['schema_version','image_mode','reference_mode','targets','characters','assets'],'visual_plan'):return
  self.check(d['schema_version']=='4.1.3','visual_plan.schema_version','Invalid version')
  self.enum(d['image_mode'],['ZONE','SCENE'],'visual_plan.image_mode')
  self.enum(d['reference_mode'],['IMAGE_REFERENCE','DESCRIPTION_ONLY'],'visual_plan.reference_mode')
  if im:self.check(d['image_mode']==im.get('image_mode'),'visual_plan.image_mode','Image prompts mode mismatch')
  targets=d['targets'];self.exact(targets,['landscape','portrait'],'visual_plan.targets')
  if isinstance(targets,dict):
   for orientation,ratio in [('landscape','16:9'),('portrait','9:16')]:
    t=targets.get(orientation)
    if not self.exact(t,['size_policy','preferred_aspect_ratio','width','height'],'visual_plan.targets.'+orientation):continue
    self.enum(t['size_policy'],['MODEL_DEFAULT','EXACT'],'targets.size_policy')
    self.check(t['preferred_aspect_ratio']==ratio,'targets.preferred_aspect_ratio','Wrong ratio designation')
    if t['size_policy']=='MODEL_DEFAULT':self.check(t['width'] is None and t['height'] is None,'targets.dimensions','MODEL_DEFAULT requires null dimensions')
    else:self.integer(t['width'],'targets.width',1);self.integer(t['height'],'targets.height',1)
  chars=self.array(d['characters'],'visual_plan.characters');ids=set();story_ids={c.get('character_id') for c in story.get('characters',[]) if isinstance(c,dict)}
  for i,c in enumerate(chars):
   w=f'visual_plan.characters[{i}]'
   if not self.exact(c,['character_id','planned_reference_path','reference_path','reference_status','description_lock'],w):continue
   cid=c['character_id'];self.check(cid in story_ids and cid not in ids,w+'.character_id','Duplicate/unknown character');ids.add(cid)
   self.string(c['description_lock'],w+'.description_lock')
   if d['reference_mode']=='DESCRIPTION_ONLY':self.check(c['planned_reference_path'] is None and c['reference_path'] is None and c['reference_status']=='NOT_APPLICABLE',w,'Invalid DESCRIPTION_ONLY combination')
   else:
    self.check(c['planned_reference_path']==f'characters/{cid}.png',w+'.planned_reference_path','Invalid planned path')
    self.enum(c['reference_status'],['PENDING','READY','FAILED'],w+'.reference_status')
    self.check(c['reference_path']==c['planned_reference_path'] if c['reference_status']=='READY' else c['reference_path'] is None,w+'.reference_path','Invalid reference path/status')
  assets=self.array(d['assets'],'visual_plan.assets');bases=[];all_people=set();scripts={s.get('id') for s in story.get('script',[]) if isinstance(s,dict)}
  for i,a in enumerate(assets):
   w=f'visual_plan.assets[{i}]'
   if not self.exact(a,['basename','role','source_script_ids','character_ids','brief','landscape_prompt','portrait_prompt'],w):continue
   bases.append(a['basename']);self.enum(a['role'],['COVER','GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL','OUTRO','SCENE'],w+'.role')
   for k in ['brief','landscape_prompt','portrait_prompt']:self.string(a[k],w+'.'+k)
   for sid in self.array(a['source_script_ids'],w+'.source_script_ids'):self.check(sid in scripts,w+'.source_script_ids','Unknown script ID')
   for cid in self.array(a['character_ids'],w+'.character_ids'):self.check(cid in story_ids,w+'.character_ids','Unknown character ID');all_people.add(cid)
  self.check(ids==all_people,'visual_plan.characters','Character set not equal to asset union')
  if d['image_mode']=='ZONE':self.check(bases==ZONE,'visual_plan.assets','ZONE expected basename list')
  else:self.check(bases[:2]==ZONE[:2] and bases[-2:]==ZONE[-2:] and bases[2:-2]==[f'scene_{i:04}.png' for i in range(1,len(bases)-3)],'visual_plan.assets','SCENE basename mismatch')
  if im and isinstance(im.get('assets'),list):self.check(bases==[a.get('basename') for a in im['assets'] if isinstance(a,dict)],'visual_plan.assets','Image prompt asset mapping mismatch')
  # Validate actual provided PNG images, not textual claims of source provenance or visual parity.
  for orientation in ['landscape','portrait'] if stage==3 else ['landscape']:
   for b in bases:
    p=f'{orientation}/{b}'
    if p not in raw:self.fail(p,'Required image absent');continue
    try:
     pic=Image.open(io.BytesIO(raw[p]));pic.verify()
     pic=Image.open(io.BytesIO(raw[p]));w,h=pic.size
     self.check(pic.format=='PNG',p,'Not PNG')
     self.check(w>h if orientation=='landscape' else h>w,p,'Wrong image orientation')
     t=targets[orientation]
     if t['size_policy']=='EXACT':self.check([w,h]==[t['width'],t['height']],p,'EXACT size mismatch')
    except Exception as exc:self.fail(p,'Image decode error: '+str(exc))
 def package(self,raw):
  j={}
  for name in ['story.json','image_prompts.json','video_prompts.json','validation_report.json','manifest.json']:
   if name not in raw:self.fail('package.'+name,'Missing file');continue
   try:j[name]=strict_load(raw[name])
   except Exception as e:self.fail('package.'+name,'JSON invalid: '+str(e))
  if 'story.json' in j:self.story(j['story.json'])
  if 'story.json' in j and 'image_prompts.json' in j:self.image_prompts(j['image_prompts.json'],raw['story.json'],j['story.json'])
  if 'story.json' in j and 'video_prompts.json' in j:self.video(j['video_prompts.json'],j['story.json'])
  if 'story.json' in j and 'manifest.json' in j and j['manifest.json'].get('stage',0)>=2:
   if 'visual_plan.json' not in raw:self.fail('visual_plan.json','Missing Stage 2/3 plan')
   else:
    try:self.visual_plan(strict_load(raw['visual_plan.json']),j['story.json'],j.get('image_prompts.json'),raw,j['manifest.json']['stage'])
    except Exception as e:self.fail('visual_plan.json','Validator could not parse plan: '+str(e))
   if 'visual_bible.txt' not in raw:self.fail('visual_bible.txt','Missing Stage 2/3 visual bible')
  if 'manifest.json' in j:
   m=j['manifest.json']
   if self.exact(m,['schema_version','prompt_version','stage','status','parent_package_sha256','files'],'manifest'):
    self.check(m['schema_version']=='5.0.0' and m['prompt_version']=='5.2.2','manifest.version','Version mismatch')
    declared={}
    for i,e in enumerate(self.array(m['files'],'manifest.files')):
     if not self.exact(e,['path','size_bytes','sha256','origin_stage'],f'manifest.files[{i}]'):continue
     p=e['path'];self.check(p not in declared,'manifest.files','Duplicate path');declared[p]=e
     if p not in raw:self.fail('manifest.files.'+p,'Declared file missing');continue
     self.check(e['size_bytes']==len(raw[p]),'manifest.files.'+p,'Size mismatch')
     self.check(e['sha256']==hashlib.sha256(raw[p]).hexdigest(),'manifest.files.'+p,'SHA-256 mismatch')
    self.check(set(declared)==set(raw)-{'manifest.json'},'manifest.files','Manifest file set mismatch')
  if 'validation_report.json' in j:
   r=j['validation_report.json']
   if self.exact(r,['schema_version','prompt_version','stage','status','input_sources','checks','limitations','remaining_work','archive_validation'],'report'):
    self.check(r['schema_version']=='5.0.0' and r['prompt_version']=='5.2.2','report.version','Wrong version')
    self.exact(r['archive_validation'],['status','details'],'report.archive_validation')
    for i,c in enumerate(self.array(r['checks'],'report.checks')):self.exact(c,['id','status','method','required','target','details'],f'report.checks[{i}]')
    if 'manifest.json' in j:self.check(r['stage']==j['manifest.json']['stage'] and r['status']==j['manifest.json']['status'],'report.manifest','Stage/status conflict')
  if 'story.json' in j and j['story.json'].get('meta',{}).get('profile')=='SERIAL_DETECTIVE':
   if 'series_anchor.json' not in j and 'series_anchor.json' not in raw:self.fail('series_anchor.json','Missing serial anchor')
  return self.issues

def strict_load(b):
 def pairs(ps):
  d={};seen=set()
  for k,v in ps:
   nk=unicodedata.normalize('NFC',k)
   if k in d or nk in seen:raise ValueError('Duplicate key raw/NFC: '+k)
   d[k]=v;seen.add(nk)
  return d
 def reject(x):raise ValueError('Non-finite JSON: '+x)
 s=b.decode('utf-8-sig')
 if s.startswith('\ufeff'):raise ValueError('BOM')
 d=json.loads(s,object_pairs_hook=pairs,parse_constant=reject)
 def scan(v):
  if isinstance(v,str):
   if any(0xD800<=ord(c)<=0xDFFF for c in v):raise ValueError('Unpaired surrogate')
  elif isinstance(v,list):
   for x in v:scan(x)
  elif isinstance(v,dict):
   for k,x in v.items():scan(k);scan(x)
 scan(d);return d

def audit_zip(path):
 a=Audit();raw={}
 try:
  with zipfile.ZipFile(path) as z:
   names=z.namelist()
   for info in z.infolist():
    p=info.filename
    if p in raw:a.fail(p,'Duplicate ZIP member')
    if p.startswith('/') or '..' in p.split('/') or '\\' in p or p.endswith('/'):a.fail(p,'Unsafe/invalid ZIP member')
    if info.create_system==3 and (info.external_attr>>16)&0o170000 in (0o120000,0o020000,0o060000):a.fail(p,'Symlink/device ZIP member')
    raw[p]=z.read(info)
   bad=z.testzip()
   if bad:a.fail(bad,'ZIP CRC failed')
 except Exception as e:a.fail(str(path),'Archive unreadable: '+str(e))
 if raw:a.package(raw)
 return {'file':str(path),'members':len(raw),'issue_count':len(a.issues),'issues':a.issues}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('zips',nargs='+');ap.add_argument('--output');args=ap.parse_args()
 results=[audit_zip(x) for x in args.zips]
 out={'validator':'v5.2.2_phase3_closed_structural_subset','scope':'static schema, source bindings, spans, manifest and ZIP; excludes content review, verified tokenizer, full anchor transitions','results':results}
 if args.output:Path(args.output).write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
 for r in results:print(Path(r['file']).name, 'members',r['members'],'schema_errors',r['issue_count']);print('   ', '; '.join(x['path']+': '+x['issue'] for x in r['issues'][:5]))
 return 0
if __name__=='__main__':sys.exit(main())
