#!/usr/bin/env python3
"""Phase 2 isolated closed-schema serial anchor conformance and transition regression.
Not a validated Chroma tokenizer, image generator, or full pipeline certification.
"""
import copy, hashlib, io, json, re, sys, unittest, zipfile
from pathlib import Path
from test_story_v522 import strict_json, h, verify_archive, manifest_match, valid_story
ROOT=Path('/mnt/data')

def ck(condition, message):
    if not condition: raise ValueError(message)
def keys(x, expected, path):
    ck(type(x) is dict, f'{path}: object required')
    ck(set(x)==set(expected.split()),f'{path}: keys unexpected/missing {set(x)^set(expected.split())}')
def s(x): return isinstance(x,str) and bool(x.strip())
def seq(x): return type(x) is list
def num(x):return type(x) in (int,float) and x>0
def nat(x):return type(x) is int and x>=0
def uniq(a):return len(a)==len(set(a))
def strarr(x):return seq(x) and all(s(y) for y in x) and uniq(x)

def validate_story_core(o):
    keys(o,'schema_version meta characters outline script','story');ck(o['schema_version']=='4.1.3','story version')
    m=o['meta'];keys(m,'title series episode author channel profile age_band language genre tone target_minutes estimated_minutes timing_method tags','meta')
    ck(all(s(m[k]) for k in ('title','author','channel','genre','tone','timing_method','language')),'meta strings')
    ck(m['series'] is None or s(m['series']),'series');ck(type(m['episode']) is int and m['episode']>=1,'episode')
    ck(m['profile'] in ('YOUTH_SAFE','ADULT_STANDARD','SERIAL_DETECTIVE'),'profile')
    ck(m['age_band'] in ('3-6','7-10','11-14','15-18') if m['profile']=='YOUTH_SAFE' else m['age_band']=='18+','age band')
    ck(num(m['target_minutes']) and (m['estimated_minutes'] is None or num(m['estimated_minutes'])),'minutes')
    ck(strarr(m['tags']),'tags')
    ck(seq(o['characters']) and o['characters'],'characters')
    ids=[]
    for i,c in enumerate(o['characters']):
        keys(c,'character_id name age role appearance personality voice_note',f'character{i}')
        ck(re.fullmatch('c[0-9]{3,}',c['character_id']) is not None,'char ID')
        ck(all(s(c[k]) for k in ('name','role','appearance','personality','voice_note')),'char fields')
        ck(c['age'] is None or nat(c['age']),'char age')
        ids.append(c['character_id'])
    ck(uniq(ids),'char ids duplicate')
    ck(seq(o['outline']) and o['outline'],'outline')
    scenes=[]
    for i,v in enumerate(o['outline'],1):
        keys(v,'scene_id summary change setup_or_payoff','outline item')
        ck(v['scene_id']==f'sc{i:03d}' and s(v['summary']) and s(v['change']),'scene fields')
        ck(v['setup_or_payoff'] is None or isinstance(v['setup_or_payoff'],str),'setup')
        scenes.append(v['scene_id'])
    ck(seq(o['script']) and o['script'],'script')
    present=[]
    for i,v in enumerate(o['script'],1):
        keys(v,'id zone scene_id speaker text emotion speed pause_ms ambience','script item')
        ck(v['id']==f's{i:04d}','script ID')
        ck(v['zone'] in ('GREETING','OPENING','INTRODUCTION','DEVELOPMENT','CLIMAX','FALLING','ENDING','FAREWELL'),'zone')
        ck(v['scene_id'] in scenes and (v['speaker']=='narrator' or v['speaker'] in ids),'script refs')
        ck(s(v['text']) and isinstance(v['emotion'],str) and num(v['speed']) and nat(v['pause_ms']),'script content')
        ck(v['ambience'] is None or isinstance(v['ambience'],str),'ambience')
        present.append(v['scene_id'])
    ck(list(dict.fromkeys(present))==scenes,'scene sequence/coverage')
    ck(all(present.count(scene)==(max(j for j,x in enumerate(present) if x==scene)-min(j for j,x in enumerate(present) if x==scene)+1) for scene in scenes),'scene contiguity')
    if m['profile']=='SERIAL_DETECTIVE':ck(s(m['series']),'serial series')
    else:ck(m['episode']==1 if m['series'] is None else True,'standalone episode')
    return True

def validate_anchor(a, story=None, require_canonical=True):
    keys(a,'schema_version series_title last_completed_episode characters canon_facts open_threads resolved_threads episode_summaries series_state','anchor')
    ck(a['schema_version']=='4.1.3' and s(a['series_title']) and nat(a['last_completed_episode']),'anchor head')
    n=a['last_completed_episode'];cs=a['characters'];ck(seq(cs),'anchor chars');charids=[]
    for c in cs:
        keys(c,'character_id name established_facts known_facts','anchor char');ck(s(c['character_id']) and s(c['name']),'char val')
        ck(strarr(c['established_facts']) and strarr(c['known_facts']),'char fact lists');charids.append(c['character_id'])
    ck(uniq(charids),'char duplication')
    facts=[]
    for f in a['canon_facts']:
        keys(f,'fact_id text established_episode','fact');ck(s(f['fact_id']) and s(f['text']) and type(f['established_episode']) is int and 1<=f['established_episode']<=n,'fact value');facts.append(f['fact_id'])
    ck(uniq(facts),'fact duplication')
    threadids=[];openids=[]
    for mode in ('open_threads','resolved_threads'):
        for t in a[mode]:
            keys(t,'thread_id description clues','thread');ck(s(t['thread_id']) and s(t['description']) and strarr(t['clues']),'thread fields')
            threadids.append(t['thread_id'])
            if mode=='open_threads':openids.append(t['thread_id'])
    ck(uniq(threadids),'thread id union duplication')
    summaries=[]
    for item in a['episode_summaries']:
        keys(item,'episode summary','summary');ck(type(item['episode']) is int and s(item['summary']),'summary field');summaries.append(item['episode'])
    ck(summaries==list(range(1,n+1)),'summary must cover episodes 1..N')
    st=a['series_state'];keys(st,'status next_episode_contract milestones clues consequences visual_locks episode_designs','series_state')
    ck(st['status'] in ('ACTIVE','COMPLETED','UNKNOWN'),'status enum')
    c=st['next_episode_contract']
    if c is not None:
        keys(c,'episode premise required_thread_ids forbidden_resolutions','contract')
        ck(type(c['episode']) is int and c['episode']==n+1 and s(c['premise']),'contract episode')
        ck(strarr(c['required_thread_ids']) and strarr(c['forbidden_resolutions']),'contract arrays')
        ck(set(c['required_thread_ids'])<=set(openids),'contract references open threads')
    if st['status']=='ACTIVE' and n>0:ck(c is not None,'ACTIVE must have contract')
    if st['status']=='COMPLETED':ck(c is None,'COMPLETED contract must be null')
    if n==0 and require_canonical:ck(st['status'] in ('ACTIVE','UNKNOWN'),'baseline status')
    mids=[]
    for m in st['milestones']:
        keys(m,'milestone_id description target_episode required status resolution','milestone')
        ck(s(m['milestone_id']) and s(m['description']) and (m['target_episode'] is None or (type(m['target_episode']) is int and m['target_episode']>=1)),'milestone fields')
        ck(type(m['required']) is bool and m['status'] in ('PLANNED','FULFILLED','CANCELLED'),'milestone state')
        ck(m['resolution'] is None if m['status']=='PLANNED' else s(m['resolution']),'milestone resolution')
        mids.append(m['milestone_id'])
    ck(uniq(mids),'milestone duplicates')
    clues=[]
    for q in st['clues']:
        keys(q,'clue_id thread_id observation interpretation status introduced_episode revealed_episode known_by source_script_ids','clue')
        ck(s(q['clue_id']) and q['thread_id'] in threadids and s(q['observation']),'clue base')
        ck(q['interpretation'] is None or s(q['interpretation']),'clue interpretation')
        ck(q['status'] in ('UNRESOLVED','VERIFIED','REFUTED') and type(q['introduced_episode']) is int and 1<=q['introduced_episode']<=n,'clue state')
        ck(q['revealed_episode'] is None if q['status']=='UNRESOLVED' else type(q['revealed_episode']) is int and q['introduced_episode']<=q['revealed_episode']<=n,'reveal')
        ck(strarr(q['known_by']) and set(q['known_by'])<=set(charids),'clue knows')
        ck(strarr(q['source_script_ids']) and bool(q['source_script_ids']) and all(re.fullmatch('s[0-9]{4,}',i) for i in q['source_script_ids']),'clue locator')
        clues.append(q['clue_id'])
    ck(uniq(clues),'clue duplicates')
    cons=[]
    for v in st['consequences']:
        keys(v,'consequence_id description established_episode status resolution','consequence')
        ck(s(v['consequence_id']) and s(v['description']) and type(v['established_episode']) is int and 1<=v['established_episode']<=n,'consequence val')
        ck(v['status'] in ('ACTIVE','RESOLVED'),'consequence status')
        ck(v['resolution'] is None if v['status']=='ACTIVE' else s(v['resolution']),'consequence res')
        cons.append(v['consequence_id'])
    ck(uniq(cons),'consequence duplicate')
    locks=[]
    for v in st['visual_locks']:
        keys(v,'character_id appearance wardrobe props','visual lock')
        ck(v['character_id'] in charids and s(v['appearance']) and s(v['wardrobe']) and strarr(v['props']),'lock val')
        locks.append(v['character_id'])
    ck(uniq(locks),'lock dup')
    ep=[]
    cases=('MISSING_PERSON','IDENTITY_DISPUTE','OWNERSHIP_PROVENANCE_DISPUTE','CONCEALED_HARM','WITNESS_CREDIBILITY_CASE','UNEXPLAINED_EVENT','OTHER')
    for v in st['episode_designs']:
        keys(v,'episode central_question case_type clue_media decisive_choice ending_consequence','design')
        ck(type(v['episode']) is int and 1<=v['episode']<=n and all(s(v[k]) for k in ('central_question','decisive_choice','ending_consequence')),'design values')
        ck(v['case_type'] in cases and strarr(v['clue_media']),'design type');ep.append(v['episode'])
    ck(ep==list(range(1,n+1)) if n>0 else ep==[],'design history coverage for synthetic complete series')
    if st['status']=='COMPLETED':
        ck(not any(m['required'] and m['status']=='PLANNED' for m in st['milestones']),'outstanding required milestone')
    if story:
        validate_story_core(story)
        ck(story['meta']['profile']=='SERIAL_DETECTIVE' and story['meta']['episode']==n and story['meta']['series']==a['series_title'],'story/anchor binding')
        current_ids={x['id'] for x in story['script']}
        for q in st['clues']:
            if q['introduced_episode']==n:ck(set(q['source_script_ids'])<=current_ids,'current clue locator')
    return True

def new_anchor(n, status):
    ck(n in (0,1,2,3),'fixture episode')
    a={'schema_version':'4.1.3','series_title':'Dấu vết cuối hẻm','last_completed_episode':n,
       'characters':[{'character_id':'c001','name':'An','established_facts':['Điều tra viên'],'known_facts':['Biết khu phố cũ']}] if n else [],
       'canon_facts':[{'fact_id':f'f{i:03d}','text':f'Chứng cứ sự kiện tập {i}','established_episode':i} for i in range(1,n+1)],
       'open_threads':([] if n==3 else [{'thread_id':'t_main','description':'Nguồn tin bị che giấu','clues':[]}]) if n else [],
       'resolved_threads':([{'thread_id':'t_main','description':'Nguồn tin bị che giấu','clues':[]} ] if n==3 else []),
       'episode_summaries':[{'episode':i,'summary':f'Tập {i} điều tra chứng cứ'} for i in range(1,n+1)],
       'series_state':{'status':status,'next_episode_contract': {'episode':n+1,'premise':'Điều tra tiếp nguồn chứng cứ','required_thread_ids':['t_main'],'forbidden_resolutions':['Không lộ nhân chứng sớm']} if status=='ACTIVE' and n>0 else None,
          'milestones':[{'milestone_id':'m_main','description':'Xác minh nguồn tin','target_episode':3,'required':True,'status':'FULFILLED' if n==3 else 'PLANNED','resolution':'Tập 3, s0005 xác minh nguồn tin' if n==3 else None}] if n else [],
          'clues':[{'clue_id':f'q{i:03d}','thread_id':'t_main','observation':f'Dấu vật chứng tập {i}','interpretation':None if i==n and n<3 else 'Dữ kiện được xác minh', 'status':'UNRESOLVED' if i==n and n<3 else 'VERIFIED','introduced_episode':i,'revealed_episode':None if i==n and n<3 else n,'known_by':['c001'],'source_script_ids':['s0005']} for i in range(1,n+1)],
          'consequences':[],
          'visual_locks':[{'character_id':'c001','appearance':'Tóc đen','wardrobe':'Áo khoác xanh','props':[]} ] if n else [],
          'episode_designs':[{'episode':i,'central_question':f'Ai giấu chứng cứ tập {i}?','case_type':'WITNESS_CREDIBILITY_CASE' if i==1 else 'UNEXPLAINED_EVENT' if i==2 else 'CONCEALED_HARM','clue_media':['lời khai'],'decisive_choice':'Công bố bằng chứng','ending_consequence':'Tiến triển điều tra'} for i in range(1,n+1)]}}
    # preserve original clue state when verified, including earlier history
    if n==0:a['series_state']['status']='ACTIVE'
    return a

def episode(n):
    d=valid_story();d['meta']['profile']='SERIAL_DETECTIVE';d['meta']['series']='Dấu vết cuối hẻm';d['meta']['episode']=n
    d['meta']['title']=f'Tập {n}: Dấu vết'
    d['script'][4]['text']=f'Tập {n}, An kiểm tra dấu vật chứng và đối chiếu lời khai.'
    return d

def transition(prev, nxt, operation, story):
    validate_anchor(prev)
    validate_anchor(nxt,story)
    n=prev['last_completed_episode'];ck(nxt['last_completed_episode']==n+1,'episode increment')
    ck(operation==('START' if n==0 else 'FINALIZE' if nxt['series_state']['status']=='COMPLETED' else 'CONTINUE'),'operation mismatch')
    ck(prev['series_title']==nxt['series_title'],'series identity')
    ck(nxt['episode_summaries'][:n]==prev['episode_summaries'],'summary history')
    ck(nxt['canon_facts'][:len(prev['canon_facts'])]==prev['canon_facts'],'canon history')
    ck(nxt['series_state']['episode_designs'][:n]==prev['series_state']['episode_designs'],'design history')
    ck(nxt['series_state']['status']==('COMPLETED' if operation=='FINALIZE' else 'ACTIVE'),'state transition')
    ck(n==0 or prev['series_state']['status']=='ACTIVE','cannot continue completed')
    prev_threads={q['thread_id'] for q in prev['open_threads']+prev['resolved_threads']};next_threads={q['thread_id'] for q in nxt['open_threads']+nxt['resolved_threads']}
    ck(prev_threads<=next_threads,'thread erased')
    if operation=='FINALIZE':ck(not nxt['open_threads'],'final requires no open major thread in synthetic scenario')
    return True

class Phase2(unittest.TestCase):
    def setUp(self):
        self.a=[new_anchor(0,'ACTIVE'),new_anchor(1,'ACTIVE'),new_anchor(2,'ACTIVE'),new_anchor(3,'COMPLETED')]
    def test_01_story_core_positive(self):self.assertTrue(validate_story_core(episode(1)))
    def test_02_story_unknown_field_negative(self):
        d=episode(1);d['characters'][0]['legacy']='x';self.assertRaises(ValueError,validate_story_core,d)
    def test_03_story_invalid_profile_age(self):
        d=episode(1);d['meta']['age_band']='7-10';self.assertRaises(ValueError,validate_story_core,d)
    def test_04_story_unknown_scene(self):
        d=episode(1);d['script'][-1]['scene_id']='sc999';self.assertRaises(ValueError,validate_story_core,d)
    def test_05_story_bool_speed(self):
        d=episode(1);d['script'][0]['speed']=True;self.assertRaises(ValueError,validate_story_core,d)
    def test_06_baseline_valid(self):self.assertTrue(validate_anchor(self.a[0]))
    def test_07_start_positive(self):self.assertTrue(transition(self.a[0],self.a[1],'START',episode(1)))
    def test_08_continue_positive(self):self.assertTrue(transition(self.a[1],self.a[2],'CONTINUE',episode(2)))
    def test_09_finalize_positive(self):self.assertTrue(transition(self.a[2],self.a[3],'FINALIZE',episode(3)))
    def test_10_anchor_legacy_root_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state_legacy']=d.pop('series_state');self.assertRaises(ValueError,validate_anchor,d)
    def test_11_anchor_extra_field_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['revision']=1;self.assertRaises(ValueError,validate_anchor,d)
    def test_12_unknown_status_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['status']='RUNNING';self.assertRaises(ValueError,validate_anchor,d)
    def test_13_completed_contract_negative(self):
        d=copy.deepcopy(self.a[3]);d['series_state']['next_episode_contract']={'episode':4,'premise':'Sai','required_thread_ids':[],'forbidden_resolutions':[]};self.assertRaises(ValueError,validate_anchor,d)
    def test_14_contract_episode_wrong_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['next_episode_contract']['episode']=9;self.assertRaises(ValueError,validate_anchor,d)
    def test_15_contract_thread_missing_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['next_episode_contract']['required_thread_ids']=['nonexistent'];self.assertRaises(ValueError,validate_anchor,d)
    def test_16_milestone_required_planned_final_negative(self):
        d=copy.deepcopy(self.a[3]);d['series_state']['milestones'][0]['status']='PLANNED';d['series_state']['milestones'][0]['resolution']=None;self.assertRaises(ValueError,validate_anchor,d)
    def test_17_clue_invalid_source_id_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['clues'][0]['source_script_ids']=['s9999'];self.assertRaises(ValueError,validate_anchor,d,episode(1))
    def test_18_clue_invalid_known_by_negative(self):
        d=copy.deepcopy(self.a[2]);d['series_state']['clues'][0]['known_by']=['c999'];self.assertRaises(ValueError,validate_anchor,d)
    def test_19_clue_wrong_thread_negative(self):
        d=copy.deepcopy(self.a[1]);d['series_state']['clues'][0]['thread_id']='unknown';self.assertRaises(ValueError,validate_anchor,d)
    def test_20_clue_unresolved_reveal_negative(self):
        d=copy.deepcopy(self.a[2]);d['series_state']['clues'][-1]['revealed_episode']=2;self.assertRaises(ValueError,validate_anchor,d)
    def test_21_summaries_gap_negative(self):
        d=copy.deepcopy(self.a[3]);d['episode_summaries'].pop(1);self.assertRaises(ValueError,validate_anchor,d)
    def test_22_future_fact_negative(self):
        d=copy.deepcopy(self.a[2]);d['canon_facts'][-1]['established_episode']=3;self.assertRaises(ValueError,validate_anchor,d)
    def test_23_reuse_fact_id_negative(self):
        d=copy.deepcopy(self.a[2]);d['canon_facts'][-1]['fact_id']=d['canon_facts'][0]['fact_id'];self.assertRaises(ValueError,validate_anchor,d)
    def test_24_erase_history_negative(self):
        d=copy.deepcopy(self.a[2]);d['canon_facts']=[];self.assertRaises(ValueError,transition,self.a[1],d,'CONTINUE',episode(2))
    def test_25_erase_episode_design_negative(self):
        d=copy.deepcopy(self.a[2]);d['series_state']['episode_designs'][0]['central_question']='retcon without approval';self.assertRaises(ValueError,transition,self.a[1],d,'CONTINUE',episode(2))
    def test_26_skip_episode_negative(self):
        d=copy.deepcopy(self.a[3]);self.assertRaises(ValueError,transition,self.a[1],d,'FINALIZE',episode(3))
    def test_27_continue_completed_negative(self):
        d=copy.deepcopy(self.a[3]);self.assertRaises(ValueError,transition,self.a[3],d,'CONTINUE',episode(3))
    def test_28_wrong_series_binding_negative(self):
        d=episode(2);d['meta']['series']='wrong';self.assertRaises(ValueError,transition,self.a[1],self.a[2],'CONTINUE',d)
    def test_29_serial_script_locator_live_positive(self):self.assertTrue(validate_anchor(self.a[3],episode(3)))
    def test_30_wrong_milestone_resolution_negative(self):
        d=copy.deepcopy(self.a[3]);d['series_state']['milestones'][0]['resolution']=None;self.assertRaises(ValueError,validate_anchor,d)
    def test_31_fixture_archives_not_complete(self):
        for n in range(1,4):
            f=ROOT/f'story_v522_fixture_stage{n}_PARTIAL.zip'
            raw=f.read_bytes(); fs=verify_archive(raw);self.assertTrue(manifest_match(fs))
            report=strict_json(fs['validation_report.json']);manifest=strict_json(fs['manifest.json'])
            self.assertEqual(report['status'],'PARTIAL');self.assertEqual(manifest['status'],'PARTIAL')
    def test_32_fixture_stage1_schema_rejection(self):
        fs=verify_archive((ROOT/'story_v522_fixture_stage1_PARTIAL.zip').read_bytes())
        v=strict_json(fs['video_prompts.json'])
        self.assertNotIn('timing_config',v) # demonstrates earlier fixture is intentionally not full schema
    def test_33_archive_hash_inheritance(self):
        fs=[verify_archive((ROOT/f'story_v522_fixture_stage{n}_PARTIAL.zip').read_bytes()) for n in (1,2,3)]
        for name in ('story.json','image_prompts.json','video_prompts.json'):
            self.assertEqual(fs[0][name],fs[1][name]);self.assertEqual(fs[1][name],fs[2][name])
        self.assertEqual(fs[1]['visual_plan.json'],fs[2]['visual_plan.json'])
    def test_34_checkpoint_snapshot_no_implicit_overwrite(self):
        a=copy.deepcopy(self.a[2]);b=copy.deepcopy(a);b['canon_facts'][-1]['text']='Correction requires authorized retcon'
        self.assertNotEqual(a,b);self.assertEqual(a['canon_facts'][-1]['text'],'Chứng cứ sự kiện tập 2')

if __name__=='__main__':
    unittest.main(verbosity=2)
