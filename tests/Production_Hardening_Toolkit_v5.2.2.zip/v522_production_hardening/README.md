# Production Hardening Toolkit — ChatGPT Audio Story Package v5.2.2

## Kết luận hiện tại
- **CONTROLLED_PILOT = PILOT_GO_WITH_WAIVERS** (theo chính sách bên ngoài).
- **STRICT_PRODUCTION = NO_GO** vì thiếu bằng chứng ở các gate native tokenizer, forced alignment, image parity, end-to-end thật và 79 formal acceptance.
- Không thay đổi prompt, schema, enum, `validation_report.json` hoặc các ZIP của Stage.
- Bộ test cũ chỉ phản ánh phạm vi test đã triển khai, không phải nghiệm thu 79 ca.

## Chạy lại
Ở thư mục vừa giải nén, có Python, Pillow, numpy và những thư viện được các test cũ yêu cầu:

```bash
python v522_production_hardening/run_hardening.py
```

Kết quả: `v522_production_hardening/hardening_results.json` và `Bao_cao_Production_Hardening_v5.2.2.md`. Test WAV yêu cầu `espeak` (hoặc môi trường tương đương) và chạy lại có thể ghi đè file thử nghiệm thuộc bundle.

## Các tệp chính
- `release_policy.json`: chính sách STRICT vs CONTROLLED_PILOT vs CONTENT_ONLY.
- `acceptance_79_matrix.csv`: bản ghi từng ca của hợp đồng prompt, tất cả giữ `NOT_RUN_AS_FORMAL_ACCEPTANCE` cho đến khi có kết quả tương ứng.
- `tokenizer_deployment_lock_TEMPLATE.json`: chỗ điền provenance sau khi thực sự tải và kiểm tokenizer.
- `hardening_results.json`: dữ liệu thật đã kiểm tại thời điểm đóng gói.

## Giới hạn an toàn và tính đúng đắn
- `PILOT_GO_WITH_WAIVERS` KHÔNG cho phép đổi gate `NOT_CHECKED` thành `PASS` trong artifact.
- Không cấp `story_stage1.zip COMPLETE` khi tokenizer chưa được xác thực theo prompt 5.2.2.
- Không dùng fixture synthetic để chứng nhận nội dung hoặc ảnh AI thật.
- Việc đóng gói toolkit test độc lập không đồng nghĩa đóng validator trong official `story.zip`.
