import csv,re,json,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent; OUT=Path(__file__).resolve().parent
prompt=(ROOT/'ChatGPT_prompt_v5.2.2.txt').read_text(encoding='utf-8')
rows=[]
for prefix,start,end in [('T',1,60),('R',61,67),('CIP',1,12)]:
 for n in range(start,end+1):
  identifier=prefix+f'{n:02}'
  match=re.search(r'(?m)^'+re.escape(identifier)+r'\s*[—–-]\s*(.+)$',prompt)
  if not match:raise RuntimeError('Acceptance ID not found: '+identifier)
  rows.append({'id':identifier,'definition':match.group(1).strip(),'execution_status':'NOT_RUN_AS_FORMAL_ACCEPTANCE','evidence_path':'','reviewer':'','waiver':'CONTROLLED_PILOT_ONLY; NOT STRICT_PRODUCTION'})
with (OUT/'acceptance_79_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
policy=json.loads((OUT/'release_policy.json').read_text(encoding='utf8'))
lock={'schema':'external-tool-provenance-v1','target':'lodestones/Chroma1-HD','model_revision':None,'tokenizer_model_filename':'spiece.model','tokenizer_expected_sha256':'d60acb128cf7b7f2536e8f38a5b18a05535c9e14c7a355904270e15b0945ea86','tokenizer_verified_sha256':None,'tokenizer_wrapper_config_verified':False,'special_token_policy_verified':False,'real_resolved_prompts_tokenized':0,'tokenizer_gate':'NOT_CHECKED','warning':'Expected SHA is provenance hint; it is not sufficient to verify deployment equivalence by itself.'}
(OUT/'tokenizer_deployment_lock_TEMPLATE.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf8')
readme='''# Production Hardening Toolkit — ChatGPT Audio Story Package v5.2.2

## Kết luận hiện tại
- **CONTROLLED_PILOT = PILOT_GO_WITH_WAIVERS** (theo chính sách bên ngoài).
- **STRICT_PRODUCTION = NO_GO** vì thiếu bằng chứng ở các gate native tokenizer, forced alignment, image parity, end-to-end thật và 79 formal acceptance.
- Không thay đổi prompt, schema, enum, `validation_report.json` hoặc các ZIP của Stage.
- Bộ test cũ chỉ phản ánh phạm vi test đã triển khai, không phải nghiệm thu 79 ca.

## Chạy lại
Ở thư mục vừa giải nén, có Python, Pillow, numpy và những thư viện được các test cũ yêu cầu:

```bash
python v522_production_hardening/run_hardening.py
```

Kết quả: `v522_production_hardening/hardening_results.json` và `Bao_cao_Production_Hardening_v5.2.2.md`. Test WAV yêu cầu `espeak` (hoặc môi trường tương đương) và chạy lại có thể ghi đè file thử nghiệm thuộc bundle.

## Các tệp chính
- `release_policy.json`: chính sách STRICT vs CONTROLLED_PILOT vs CONTENT_ONLY.
- `acceptance_79_matrix.csv`: bản ghi từng ca của hợp đồng prompt, tất cả giữ `NOT_RUN_AS_FORMAL_ACCEPTANCE` cho đến khi có kết quả tương ứng.
- `tokenizer_deployment_lock_TEMPLATE.json`: chỗ điền provenance sau khi thực sự tải và kiểm tokenizer.
- `hardening_results.json`: dữ liệu thật đã kiểm tại thời điểm đóng gói.

## Giới hạn an toàn và tính đúng đắn
- `PILOT_GO_WITH_WAIVERS` KHÔNG cho phép đổi gate `NOT_CHECKED` thành `PASS` trong artifact.
- Không cấp `story_stage1.zip COMPLETE` khi tokenizer chưa được xác thực theo prompt 5.2.2.
- Không dùng fixture synthetic để chứng nhận nội dung hoặc ảnh AI thật.
- Việc đóng gói toolkit test độc lập không đồng nghĩa đóng validator trong official `story.zip`.
'''
(OUT/'README.md').write_text(readme,encoding='utf8')
inputs=[ROOT/'ChatGPT_prompt_v5.2.2.txt',ROOT/'ChatGPT_prompt_v5.2.2_Quickstart.txt']
inputs += [ROOT/x for x in ['audit_story_v522_phase3.py','audit_story_v522_phase4.py','audit_story_v522_phase5.py','test_story_v522.py']+[f'test_story_v522_phase{i}.py' for i in range(2,8)]]
inputs += [ROOT/x for x in ['story_v522_fixture_stage1_PARTIAL.zip','story_v522_fixture_stage2_PARTIAL.zip','story_v522_fixture_stage3_PARTIAL.zip','story_v522_synthetic_schema_PARTIAL.zip','story_v522_serial_synthetic_fixtures.zip','story_v522_phase5_aligned_evidence_SYNTHETIC.json','story_v522_phase5_measured_video_SYNTHETIC.json','story_v522_phase6_narration_SYNTHETIC.wav','story_v522_phase6_waveform_evidence.json','story_v522_phase6_measured_video_EXPERIMENTAL.json','story_v522_phase7_continuous_narration_EXPERIMENTAL.wav']]
inputs += [ROOT/x for x in ['Bao_cao_kiem_thu_prompt_v5.2.2.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot2.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot3.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot4.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot5.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot6.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot7.json']]
inputs += list(OUT.glob('*.json'))+list(OUT.glob('*.md'))+list(OUT.glob('*.csv'))+[OUT/'run_hardening.py',OUT/'build_release.py']
missing=[str(p) for p in inputs if not p.exists()]
if missing:raise RuntimeError(missing)
target=ROOT/'Production_Hardening_Toolkit_v5.2.2.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in inputs:
  if p.parent==OUT:arc='v522_production_hardening/'+p.name
  else:arc=p.name
  z.write(p,arc)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
print('acceptance cases',len(rows),'bundle files',len(inputs),'zip bytes',target.stat().st_size,'sha256',hashlib.sha256(target.read_bytes()).hexdigest())
