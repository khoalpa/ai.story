# v5.2.2 — Controlled Pilot hardening, đợt 8

**Quyết định:** `PILOT_GO_WITH_WAIVERS`. **Production-ready:** `FALSE`.

## Chứng cứ thực thi lại

| Bộ kiểm thử | Exit code |
|---|---:|
| `test_story_v522.py` | 0 |
| `test_story_v522_phase2.py` | 0 |
| `test_story_v522_phase3.py` | 0 |
| `test_story_v522_phase4.py` | 0 |
| `test_story_v522_phase5.py` | 0 |
| `test_story_v522_phase6.py` | 0 |
| `test_story_v522_phase7.py` | 0 |

## Kiểm fixture

| ZIP | Lỗi distinct (phạm vi validator) | Trạng thái bên trong |
|---|---:|---|
| `story_v522_fixture_stage1_PARTIAL.zip` | 14 | PARTIAL |
| `story_v522_fixture_stage2_PARTIAL.zip` | 18 | PARTIAL |
| `story_v522_fixture_stage3_PARTIAL.zip` | 18 | PARTIAL |
| `story_v522_synthetic_schema_PARTIAL.zip` | 0 | PARTIAL |

## Hard gates

- regressions_rerun: **True**
- zip_schema_linkage_clean_on_control_fixture: **True**
- no_false_complete: **True**
- policy_file_present: **True**

## Chưa kiểm chứng

- tokenizer_native: **NOT_CHECKED**
- continuous_audio_forced_alignment: **NOT_CHECKED**
- real_image_pipeline: **NOT_RUN**
- full_acceptance_79: **NOT_RUN**
- semantic_quality_review: **NOT_RUN**
- real_stage1_to_stage3: **NOT_RUN**

## Phạm vi hạ chuẩn

Chấp nhận waiver *chỉ* cho quyết định `CONTROLLED_PILOT` bên ngoài artifact. Không sửa `validation_report.json`, không tự đổi `NOT_CHECKED` thành `PASS`, không cấp `COMPLETE` cho package PARTIAL. Các kiểm kỹ thuật ZIP/schema/hash và chống sai lệch không được miễn trừ.

Không đưa validator hay báo cáo kiểm thử vào gói `story.zip` chính thức. Không có gói production thực tế nào được sinh ra trong đợt này.

Cần có tokenizer deployment đã xác thực, forced alignment, image review trên ảnh thật, chạy end-to-end thật, kiểm đủ 79 acceptance và phê duyệt để đạt STRICT_PRODUCTION.
