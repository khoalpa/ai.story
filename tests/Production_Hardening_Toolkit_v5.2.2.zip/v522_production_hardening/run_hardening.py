#!/usr/bin/env python3
"""v5.2.2 Production-hardening evidence runner.
Never rewrites artifact reports or promotes a PARTIAL archive to COMPLETE.
Runs existing regression suites, combines known mechanical validators,
and issues *external* tiered decision, not a production certificate.
"""
import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from audit_story_v522_phase3 import audit_zip
from audit_story_v522_phase4 import Phase4,readzip
from audit_story_v522_phase5 import tokenizer_capability
SUITES=[f'test_story_v522{suffix}.py' for suffix in ['', '_phase2','_phase3','_phase4','_phase5','_phase6','_phase7']]
FIXTURES=['story_v522_fixture_stage1_PARTIAL.zip','story_v522_fixture_stage2_PARTIAL.zip','story_v522_fixture_stage3_PARTIAL.zip','story_v522_synthetic_schema_PARTIAL.zip']
POLICY=json.loads((OUT/'release_policy.json').read_text(encoding='utf8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def validate_fixture(path):
    phase3=audit_zip(path)
    try: phase4=Phase4().evaluate(readzip(path))
    except Exception as e:phase4=[{'path':'validator_exception','issue':repr(e)}]
    with zipfile.ZipFile(path) as z:
        report=json.loads(z.read('validation_report.json')) if 'validation_report.json' in z.namelist() else {}
    return {'name':path.name,'sha256':sha(path.read_bytes()),'status_in_archive':report.get('status'),'issues_phase3':phase3['issues'],'issues_phase4':phase4,'combined_unique_issue_count':len({(x['path'],x['issue']) for x in phase3['issues']+phase4}),'mechanical_subset_clean':not(phase3['issues'] or phase4)}
def main():
    suites=[]
    for name in SUITES:
        result=subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,capture_output=True,text=True,timeout=120)
        suites.append({'suite':name,'exit_code':result.returncode,'stdout_tail':result.stdout[-1800:],'stderr_tail':result.stderr[-1000:]})
    expected=[32,34,20,30,34,24,25]
    # Runner executes each suite; count comes from structured phase output, not assumption.
    phase_paths=['Bao_cao_kiem_thu_prompt_v5.2.2.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot2.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot3.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot4.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot5.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot6.json','Bao_cao_kiem_thu_prompt_v5.2.2_dot7.json']
    for i,path in enumerate(phase_paths):
        try:
            obj=json.loads((ROOT/path).read_text(encoding='utf8'))
            s=suites[i];s['result_file']=path
            s['result_keys']=list(obj)
            # Existing suite formats differ. Preserve the original payload for independent audit.
            s['result']=obj
        except Exception as e:suites[i]['result_read_error']=repr(e)
    fixtures=[validate_fixture(ROOT/name) for name in FIXTURES]
    tokenizer=tokenizer_capability()
    all_suites_pass=all(x['exit_code']==0 for x in suites)
    clean_fixture=next(x for x in fixtures if x['name']=='story_v522_synthetic_schema_PARTIAL.zip')
    hard_gates={'regressions_rerun':all_suites_pass,'zip_schema_linkage_clean_on_control_fixture':clean_fixture['mechanical_subset_clean'],'no_false_complete':all(x['status_in_archive']!='COMPLETE' for x in fixtures),'policy_file_present':True}
    evidence_gaps={'tokenizer_native':'NOT_CHECKED','continuous_audio_forced_alignment':'NOT_CHECKED','real_image_pipeline':'NOT_RUN','full_acceptance_79':'NOT_RUN','semantic_quality_review':'NOT_RUN','real_stage1_to_stage3':'NOT_RUN'}
    pilot_go=all(hard_gates.values())
    data={'version':'5.2.2','evaluation_profile':'CONTROLLED_PILOT','original_prompt_contract_unchanged':True,'test_expected_counts_historical':expected,'suites':suites,'fixtures':fixtures,'tokenizer_capability':tokenizer,'hard_gates':hard_gates,'evidence_gaps':evidence_gaps,'decision':'PILOT_GO_WITH_WAIVERS' if pilot_go else 'NO_GO','production_ready':False,'explanation':'An external pilot decision only. Does not certify production, Stage COMPLETE, token counts, real image pipeline or semantic checks.'}
    (OUT/'hardening_results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    md=['# v5.2.2 — Controlled Pilot hardening, đợt 8','',f"**Quyết định:** `{data['decision']}`. **Production-ready:** `FALSE`.",'','## Chứng cứ thực thi lại','', '| Bộ kiểm thử | Exit code |','|---|---:|']
    md +=[f"| `{r['suite']}` | {r['exit_code']} |" for r in suites]
    md +=['','## Kiểm fixture','', '| ZIP | Lỗi distinct (phạm vi validator) | Trạng thái bên trong |','|---|---:|---|']
    md +=[f"| `{f['name']}` | {f['combined_unique_issue_count']} | {f['status_in_archive']} |" for f in fixtures]
    md +=['','## Hard gates','']+[f'- {k}: **{v}**' for k,v in hard_gates.items()]
    md +=['','## Chưa kiểm chứng','']+[f'- {k}: **{v}**' for k,v in evidence_gaps.items()]
    md +=['','## Phạm vi hạ chuẩn','', 'Chấp nhận waiver *chỉ* cho quyết định `CONTROLLED_PILOT` bên ngoài artifact. Không sửa `validation_report.json`, không tự đổi `NOT_CHECKED` thành `PASS`, không cấp `COMPLETE` cho package PARTIAL. Các kiểm kỹ thuật ZIP/schema/hash và chống sai lệch không được miễn trừ.', '', 'Không đưa validator hay báo cáo kiểm thử vào gói `story.zip` chính thức. Không có gói production thực tế nào được sinh ra trong đợt này.', '', 'Cần có tokenizer deployment đã xác thực, forced alignment, image review trên ảnh thật, chạy end-to-end thật, kiểm đủ 79 acceptance và phê duyệt để đạt STRICT_PRODUCTION.']
    (OUT/'Bao_cao_Production_Hardening_v5.2.2.md').write_text('\n'.join(md)+'\n',encoding='utf8')
    print(json.dumps({'decision':data['decision'],'suites_exit_codes':[r['exit_code'] for r in suites],'fixture_issue_counts':{x['name']:x['combined_unique_issue_count'] for x in fixtures},'production_ready':False},ensure_ascii=False))
    return 0 if pilot_go else 1
if __name__=='__main__':raise SystemExit(main())
