#!/usr/bin/env python3
"""Phase 7: independently audit real WAV-boundary evidence and tokenizer provenance.
This is NOT forced alignment nor a verified native tokenizer count.
"""
import copy,hashlib,io,json,os,subprocess,tempfile,unittest,wave,zipfile
from pathlib import Path
import numpy as np
BASE=Path('/mnt/data')
WAV=BASE/'story_v522_phase6_narration_SYNTHETIC.wav'
EVID=BASE/'story_v522_phase6_waveform_evidence.json'
VIDEO=BASE/'story_v522_phase6_measured_video_EXPERIMENTAL.json'
ZIP=BASE/'story_v522_synthetic_schema_PARTIAL.zip'
REPO=BASE/'chroma_spiece_test.model'
EXPECTED_SHA='d60acb128cf7b7f2536e8f38a5b18a05535c9e14c7a355904270e15b0945ea86'
EXPECTED_SIZE=791656

def sha(b):return hashlib.sha256(b).hexdigest()
def wav_meta(b):
 with wave.open(io.BytesIO(b),'rb') as f:
  return f.getframerate(),f.getnframes(),f.getnchannels(),f.getsampwidth(),np.frombuffer(f.readframes(f.getnframes()),dtype='<i2')

def audit(wav,evidence,video,story_raw):
 errors=[]
 def err(s):errors.append(s)
 try: sr,n,ch,sw,samples=wav_meta(wav)
 except Exception as ex:return ['INVALID_WAV:'+str(ex)]
 if ch!=1 or sw!=2:err('FORMAT')
 if sha(wav)!=evidence.get('audio_sha256'):err('AUDIO_SHA')
 if sha(story_raw)!=evidence.get('story_sha256'):err('STORY_SHA')
 if n!=evidence.get('total_samples'):err('TOTAL_SAMPLES')
 if sr!=evidence.get('audio_sample_rate_hz'):err('SAMPLE_RATE')
 bounds=evidence.get('sample_boundaries',[]);spans=evidence.get('aligned_spans',[])
 if not bounds or len(bounds)!=len(spans):err('SPAN_COUNT')
 ids=set();last=0
 clip_seconds={}
 for i,(b,s) in enumerate(zip(bounds,spans)):
  name=b.get('clip_id');start=b.get('start_sample');end=b.get('end_sample')
  if not isinstance(start,int) or not isinstance(end,int) or start<0 or end<=start or end>n:
   err('BOUNDS');continue
  if start<last:err('OVERLAP')
  if start>last and start<=n and np.any(samples[last:start]):err('GAP_HAS_SPEECH')
  if not np.any(samples[start:min(end,n)]):err('SILENT_SPAN')
  if name!=s.get('clip_id'):err('CLIP_ID')
  if abs(start/sr-s.get('start_seconds',-1))>2e-7 or abs(end/sr-s.get('end_seconds',-1))>2e-7:err('TIMESTAMP')
  clip_seconds[name]=clip_seconds.get(name,0)+(end-start)/sr
  ids.add((name,s.get('script_id'),s.get('start_char'),s.get('end_char')))
  last=end
 story=json.loads(story_raw);texts={x['id']:x['text'] for x in story['script']}
 for s in spans:
  txt=texts.get(s.get('script_id'),'')[s.get('start_char',0):s.get('end_char',0)]
  if sha(txt.encode())!=s.get('text_sha256'):err('TEXT_SPAN_SHA')
 expected=set()
 for c in video.get('clips',[]):
  for s in c['source_spans']:expected.add((c['clip_id'],s['script_id'],s['start_char'],s['end_char']))
  if abs(clip_seconds.get(c['clip_id'],0)-(c.get('estimated_seconds') or 0))>2e-6:err('CLIP_DURATION')
 if expected!=ids:err('SOURCE_COVERAGE')
 if evidence.get('experimental_method','').find('NOT FORCED_ALIGNMENT')<0:err('EVIDENCE_PROVENANCE')
 return sorted(set(errors))

class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.wav=WAV.read_bytes();cls.e=json.loads(EVID.read_text());cls.v=json.loads(VIDEO.read_text())
  with zipfile.ZipFile(ZIP) as z:cls.story=z.read('story.json')
 def errors(self,e=None,v=None,w=None,story=None):return audit(w if w is not None else self.wav,e if e is not None else self.e,v if v is not None else self.v,story if story is not None else self.story)
 def test_01_original_evidence(self):self.assertEqual(self.errors(),[])
 def test_02_wave_header(self):self.assertEqual(self.wav[0:4],b'RIFF')
 def test_03_audio_hash(self):self.assertEqual(sha(self.wav),self.e['audio_sha256'])
 def test_04_script_hash(self):self.assertEqual(sha(self.story),self.e['story_sha256'])
 def test_05_real_audio_content(self):self.assertGreater(np.count_nonzero(wav_meta(self.wav)[4]),100)
 def test_06_sample_time_roundtrip(self):self.assertNotIn('TIMESTAMP',self.errors())
 def test_07_speech_nonsilence(self):self.assertNotIn('SILENT_SPAN',self.errors())
 def test_08_interval_nonoverlap(self):self.assertNotIn('OVERLAP',self.errors())
 def test_09_hash_tamper(self):
  e=copy.deepcopy(self.e);e['audio_sha256']='0'*64;self.assertIn('AUDIO_SHA',self.errors(e=e))
 def test_10_truncated_wave(self):self.assertTrue(self.errors(w=self.wav[:100]))
 def test_11_wrong_sample_rate(self):
  e=copy.deepcopy(self.e);e['audio_sample_rate_hz']=999;self.assertIn('SAMPLE_RATE',self.errors(e=e))
 def test_12_wrong_total_samples(self):
  e=copy.deepcopy(self.e);e['total_samples']+=1;self.assertIn('TOTAL_SAMPLES',self.errors(e=e))
 def test_13_wrong_timestamp(self):
  e=copy.deepcopy(self.e);e['aligned_spans'][0]['start_seconds']+=.05;self.assertIn('TIMESTAMP',self.errors(e=e))
 def test_14_wrong_sample_boundary(self):
  e=copy.deepcopy(self.e);e['sample_boundaries'][0]['end_sample']+=4000;self.assertIn('TIMESTAMP',self.errors(e=e))
 def test_15_overlap(self):
  e=copy.deepcopy(self.e);e['sample_boundaries'][1]['start_sample']=0;self.assertIn('OVERLAP',self.errors(e=e))
 def test_16_silent_span(self):
  w=bytearray(self.wav);b=self.e['sample_boundaries'][0];w[44+2*b['start_sample']:44+2*b['end_sample']]=b'\x00'*(2*(b['end_sample']-b['start_sample']))
  self.assertIn('SILENT_SPAN',self.errors(w=bytes(w)))
 def test_17_script_text_mismatch(self):
  e=copy.deepcopy(self.e);e['aligned_spans'][0]['text_sha256']='0'*64;self.assertIn('TEXT_SPAN_SHA',self.errors(e=e))
 def test_18_missing_span(self):
  e=copy.deepcopy(self.e);e['aligned_spans'].pop();self.assertIn('SPAN_COUNT',self.errors(e=e))
 def test_19_clip_duration_mismatch(self):
  v=copy.deepcopy(self.v);v['clips'][0]['estimated_seconds']+=5;self.assertIn('CLIP_DURATION',self.errors(v=v))
 def test_20_clip_source_mismatch(self):
  v=copy.deepcopy(self.v);v['clips'][0]['source_spans'][0]['end_char']-=1;self.assertIn('SOURCE_COVERAGE',self.errors(v=v))
 def test_21_provenance_cannot_claim_forced(self):
  e=copy.deepcopy(self.e);e['experimental_method']='FORCED_ALIGNMENT';self.assertIn('EVIDENCE_PROVENANCE',self.errors(e=e))
 def test_22_tokenizer_unavailable(self):
  self.assertFalse(REPO.exists() and REPO.stat().st_size==EXPECTED_SIZE and sha(REPO.read_bytes())==EXPECTED_SHA)
 def test_23_pipeline_tokenizer_unverified(self):
  self.assertEqual(tokenizer_gate(),'NOT_CHECKED')
 def test_24_continuous_audio_generation(self):
  with zipfile.ZipFile(ZIP) as z:story=json.loads(z.read('story.json'))
  text=' '.join(s['text'] for s in story['script'])
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'continuous.wav';subprocess.run(['espeak','-v','en','-s','145','-w',str(p),text],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   b=p.read_bytes();sr,n,ch,sw,samples=wav_meta(b)
   self.assertGreater(n/sr,1);self.assertGreater(np.count_nonzero(samples),100)
   (BASE/'story_v522_phase7_continuous_narration_EXPERIMENTAL.wav').write_bytes(b)
 def test_25_continuous_no_alignment_proof(self):
  self.assertEqual(continuous_gate(),'NOT_CHECKED')

def tokenizer_gate():
 return 'VERIFIED' if (REPO.exists() and REPO.stat().st_size==EXPECTED_SIZE and sha(REPO.read_bytes())==EXPECTED_SHA) else 'NOT_CHECKED'
def continuous_gate():return 'NOT_CHECKED' # no verified forced alignment engine present

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
 with (BASE/'test_story_v522_phase7_run.log').open('w') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
 obj={'phase':7,'tests_run':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'passed':r.testsRun-len(r.failures)-len(r.errors),'tokenizer':'NOT_CHECKED','continuous_forced_alignment':'NOT_CHECKED','note':'Independent audio evidence audit and continuous-utterance WAV generation; no forced alignment or verified T5 tokenizer'}
 (BASE/'Bao_cao_kiem_thu_prompt_v5.2.2_dot7.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
 print(obj)
 if not r.wasSuccessful():raise SystemExit(1)
