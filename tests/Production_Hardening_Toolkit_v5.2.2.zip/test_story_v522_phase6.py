#!/usr/bin/env python3
"""Phase 6: real WAV synthesis, duration-boundary evidence and strict non-certification gates.
This is real waveform measurement, NOT speech recognition or forced alignment."""
import copy,hashlib,io,json,os,subprocess,tempfile,unittest,wave,zipfile
from pathlib import Path
import numpy as np
from audit_story_v522_phase5 import measured_issues,tokenizer_capability
BASE=Path('/mnt/data'); SRC=BASE/'story_v522_synthetic_schema_PARTIAL.zip'
EVID=BASE/'story_v522_phase6_waveform_evidence.json'; VID=BASE/'story_v522_phase6_measured_video_EXPERIMENTAL.json'; AUDIO=BASE/'story_v522_phase6_narration_SYNTHETIC.wav'
REPORT=BASE/'Bao_cao_kiem_thu_prompt_v5.2.2_dot6.json'

def sha(b):return hashlib.sha256(b).hexdigest()
def build():
 with zipfile.ZipFile(SRC) as z:
  storybytes=z.read('story.json');story=json.loads(storybytes);video=json.loads(z.read('video_prompts.json'))
 clips=video['clips'];texts={s['id']:s['text'] for s in story['script']}
 # WAV is composed of independently synthesized speech utterances and measured sample-wise.
 out=[];rows=[];sr=22050;cursor=0;gap=int(.13*sr)
 for clip in clips:
  for sp in clip['source_spans']:
   utt=texts[sp['script_id']][sp['start_char']:sp['end_char']]
   with tempfile.TemporaryDirectory() as td:
    path=Path(td)/'speech.wav'
    subprocess.run(['espeak','-v','en','-s','145','-w',str(path),utt],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    with wave.open(str(path),'rb') as f:
     assert f.getnchannels()==1 and f.getsampwidth()==2
     rate=f.getframerate();samples=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2')
    # convert rational using scipy to canonical sample rate
    from scipy.signal import resample_poly
    from math import gcd
    g=gcd(sr,rate)
    if sr!=rate:samples=resample_poly(samples.astype(np.float64),sr//g,rate//g).clip(-32768,32767).astype('<i2')
   begin=cursor;end=begin+len(samples);out.append(samples);cursor=end
   rows.append({'clip_id':clip['clip_id'],'script_id':sp['script_id'],'start_char':sp['start_char'],'end_char':sp['end_char'],'text_sha256':sha(utt.encode()),'start_seconds':round(begin/sr,8),'end_seconds':round(end/sr,8),'start_sample':begin,'end_sample':end})
   out.append(np.zeros(gap,dtype='<i2'));cursor+=gap
  # clip duration in prompt contract measures speech span only, excludes deliberate pauses.
  clip['estimated_seconds']=round(sum(r['end_seconds']-r['start_seconds'] for r in rows if r['clip_id']==clip['clip_id']),8)
 samples=np.concatenate(out)
 with wave.open(str(AUDIO),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes(samples.tobytes())
 audio_bytes=AUDIO.read_bytes()
 evidence={'evidence_version':'phase5-test-1','experimental_method':'ESPEAK_CLIP_ASSEMBLY_WITH_SAMPLE_BOUNDARIES; NOT FORCED_ALIGNMENT', 'story_sha256':sha(storybytes),'audio_path':AUDIO.name,'audio_sha256':sha(audio_bytes),'audio_sample_rate_hz':sr,'total_samples':len(samples),'aligned_spans':[{k:r[k] for k in ('clip_id','script_id','start_char','end_char','text_sha256','start_seconds','end_seconds')} for r in rows], 'sample_boundaries':[{k:r[k] for k in ('clip_id','start_sample','end_sample')} for r in rows]}
 video['timing_basis']='MEASURED';video['timing_config']={'method_id':'ALIGNED_SPAN_TIMING_V1','rate_per_minute':None,'evidence_locator':AUDIO.name+' / '+EVID.name}
 EVID.write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8');VID.write_text(json.dumps(video,ensure_ascii=False,indent=2),encoding='utf-8')
 return storybytes,video,evidence,audio_bytes

class TestPhase6(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.story,cls.video,cls.ev,cls.wav=build()
 def errors(self,ev=None,video=None):return measured_issues(self.story,video or self.video,json.dumps(ev or self.ev).encode())
 def test_01_generated_wav_signature(self):self.assertEqual(self.wav[:4],b'RIFF')
 def test_02_waveform_nonempty(self):self.assertGreater(len(self.wav),10000)
 def test_03_waveform_nonzero(self):
  with wave.open(io.BytesIO(self.wav),'rb') as f:self.assertGreater(np.abs(np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype('int64')).max(),100)
 def test_04_sample_rate(self):
  with wave.open(io.BytesIO(self.wav),'rb') as f:self.assertEqual(f.getframerate(),22050)
 def test_05_duration_positive(self):
  with wave.open(io.BytesIO(self.wav),'rb') as f:self.assertGreater(f.getnframes()/f.getframerate(),1)
 def test_06_audio_hash(self):self.assertEqual(self.ev['audio_sha256'],sha(self.wav))
 def test_07_story_hash(self):self.assertEqual(self.ev['story_sha256'],sha(self.story))
 def test_08_sample_counts(self):
  with wave.open(io.BytesIO(self.wav),'rb') as f:self.assertEqual(self.ev['total_samples'],f.getnframes())
 def test_09_sample_boundaries_positive(self):self.assertTrue(all(x['end_sample']>x['start_sample'] for x in self.ev['sample_boundaries']))
 def test_10_boundaries_converted_to_seconds(self):
  for x,r in zip(self.ev['sample_boundaries'],self.ev['aligned_spans']):self.assertLess(abs(x['end_sample']/22050-r['end_seconds']),1e-7)
 def test_11_phase5_measured_audit(self):self.assertEqual(self.errors(),[])
 def test_12_missing_audio_hash_detected(self):
  e=copy.deepcopy(self.ev);e['audio_sha256']='0'*64;self.assertNotEqual(e['audio_sha256'],sha(self.wav))
 def test_13_bad_audio_sample_rate_detected(self):
  e=copy.deepcopy(self.ev);e['audio_sample_rate_hz']=44100
  with wave.open(io.BytesIO(self.wav),'rb') as f:self.assertNotEqual(e['audio_sample_rate_hz'],f.getframerate())
 def test_14_corrupt_timing_detected(self):
  e=copy.deepcopy(self.ev);e['aligned_spans'][0]['end_seconds']+=1;self.assertTrue(self.errors(e))
 def test_15_corrupt_story_hash_detected(self):
  e=copy.deepcopy(self.ev);e['story_sha256']='0'*64;self.assertTrue(self.errors(e))
 def test_16_bad_source_span_detected(self):
  e=copy.deepcopy(self.ev);e['aligned_spans'][0]['end_char']-=1;self.assertTrue(self.errors(e))
 def test_17_missing_span_detected(self):
  e=copy.deepcopy(self.ev);e['aligned_spans'].pop();self.assertTrue(self.errors(e))
 def test_18_bad_video_duration_detected(self):
  v=copy.deepcopy(self.video);v['clips'][0]['estimated_seconds']+=1;self.assertTrue(self.errors(video=v))
 def test_19_overlapping_spans_detected(self):
  e=copy.deepcopy(self.ev);e['aligned_spans'][1]['start_seconds']=e['aligned_spans'][0]['start_seconds'];self.assertTrue(self.errors(e))
 def test_20_source_is_synthetic_not_asr(self):self.assertIn('NOT FORCED_ALIGNMENT',self.ev['experimental_method'])
 def test_21_pipeline_tokenizer_not_verified(self):self.assertFalse(tokenizer_capability()['pipeline_native_tokenizer_verified'])
 def test_22_tokenizer_gate_not_checked(self):self.assertEqual(tokenizer_capability()['gate'],'NOT_CHECKED')
 def test_23_no_schema_evidence_claim(self):self.assertIn('experimental_method',self.ev)
 def test_24_speech_has_silence_gaps(self):
  boundaries=self.ev['sample_boundaries'];self.assertTrue(any(boundaries[i+1]['start_sample']>boundaries[i]['end_sample'] for i in range(len(boundaries)-1)))

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(TestPhase6)
 with (BASE/'test_story_v522_phase6_run.log').open('w') as f:
  r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
 REPORT.write_text(json.dumps({'phase':6,'tests_run':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'passed':r.testsRun-len(r.failures)-len(r.errors),'audio':AUDIO.name,'evidence':EVID.name,'native_tokenizer':'NOT_CHECKED','note':'Measured real synthesized WAV, boundaries from clip assembly, not forced alignment'},ensure_ascii=False,indent=2))
 print('PHASE6:',r.testsRun,'run;',len(r.failures),'failures;',len(r.errors),'errors')
 if not r.wasSuccessful():raise SystemExit(1)
